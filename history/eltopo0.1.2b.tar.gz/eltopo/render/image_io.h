#ifndef IMAGE_IO_H
#define IMAGE_IO_H

#include "array2.h"
#include "vec.h"

// Images are represented here as 2d arrays of 3d RGB vectors.
// (Note that an array img is interpreted so that img(i,0) is the i'th pixel from the
// left on the bottom-most scanline of the image)
//
// The filename of the image file to read or write to is given in terms of a
// printf-style format string with optional arguments following. So for example,
// you can call read_sgi(img, "frame%03d.sgi", 17) to read in file "frame017.sgi".
// Obviously you need to be careful about file names that include percent signs (%);
// read the documentation for printf for further reference.
//
// Currently only SGI format images are included here, which are the simplest widely-supported
// binary image files capable of storing 24-bit color images.

// Returns false if read fails.
bool read_sgi(Array2<Vec3f> &img, const char *filename_format, ...);

// Returns false if write fails.
bool write_sgi(const Array2<Vec3f> &img, const char *filename_format, ...);

// Returns false if write fails. This version uses lossless RLE compression to generate
// smaller files in some cases.
bool write_sgi_compressed(const Array2<Vec3f> &img, const char *filename_format, ...);

#endif
