#ifndef LIGHT_SOURCE_H
#define LIGHT_SOURCE_H

#include <cfloat>
#include <vector>
#include "primitives.h"

struct DirectedLight
{
   virtual ~DirectedLight(void) {}
   virtual void evaluate(const Vec3f& x, Vec3f& light_direction, Vec3f& light_color, float& light_distance) const = 0;
};

struct DistantLight: public DirectedLight
{
   Vec3f direction;
   Vec3f color;

   DistantLight(void) : direction(0.f,-1.f,0.f), color(1.f,1.f,1.f) {}

   DistantLight(const Vec3f& direction_, const Vec3f& color_) : direction(normalized(direction_)), color(color_) {}

   virtual void evaluate(const Vec3f& /*x*/, Vec3f& light_direction, Vec3f& light_color, float& light_distance) const
   {
      light_direction=-direction;
      light_color=color;
      light_distance=FLT_MAX;
   }
};

struct PointLight: public DirectedLight
{
   Vec3f position;
   Vec3f color;

   PointLight(void) : position(0,0,0), color(1,1,1) {}

   PointLight(const Vec3f& position_, const Vec3f& color_) : position(position_), color(color_) {}

   virtual void evaluate(const Vec3f& x, Vec3f& light_direction, Vec3f& light_color, float& light_distance) const
   {
      light_direction=position-x;
      float distance_squared=mag2(light_direction)+1e-30f; // bias it to be strictly positive
      light_distance=std::sqrt(distance_squared);
      light_direction/=light_distance;
      light_color=color/distance_squared;
   }
};

struct Lighting
{
   Vec3f ambient;
   std::vector<DirectedLight*> directed_light;

   Lighting(void) : ambient(0,0,0), directed_light(0) {}
};

#endif
