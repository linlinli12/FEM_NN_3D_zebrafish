#ifndef PRIMITIVES_H
#define PRIMITIVES_H

// Basic types and operations for the raytracer: rays and bounding boxes.

#include "vec.h"

// A ray consists of two vectors, one being the origin point and the other a direction.
// It's not enforced in this class, but it's strongly recommended for everyone's sanity
// to stick with unit-length normalized directions.
struct Ray
{
   Vec3f origin, direction;

   Ray(void) : origin(0,0,0), direction(0,0,-1) {}

   Ray(const Vec3f& origin_, const Vec3f& direction_)
      : origin(origin_), direction(direction_)
   {}
};

// an IO operator so you can more easily dump out a ray when debugging, e.g. std::cout<<ray
inline std::ostream &operator<<(std::ostream &out, const Ray& ray)
{
   out<<"(o:"<<ray.origin<<", d:"<<ray.direction<<")";
   return out;
}

// An axis-aligned bounding box, represented with two vectors---the minimum
// coordinate corner and the maximum coordinate corner.
struct BoundingBox
{
   Vec3f xmin, xmax;

   // the default is a zero-extent box at the origin
   BoundingBox(void) : xmin(0,0,0), xmax(0,0,0) {}

   // or if you give it a single point, a zero-extent box at the point
   BoundingBox(const Vec3f& x) : xmin(x), xmax(x) {}

   // if you construct it with two vectors, it assumes they are the min and the max corners
   BoundingBox(const Vec3f& xmin_, const Vec3f& xmax_)
      : xmin(xmin_), xmax(xmax_)
   { assert(xmin[0]<=xmax[0] && xmin[1]<=xmax[1] && xmin[2]<=xmax[2]); }

   // you can also build a box from a list of three points, finding the min and max for each axis.
   void build_from_points(const Vec3f& x0, const Vec3f& x1, const Vec3f& x2)
   { minmax(x0, x1, x2, xmin, xmax); }

   // you can enlarge an existing box to include a new point (if it doesn't contain it already)
   void include_point(const Vec3f& x)
   { update_minmax(x, xmin, xmax); }

   // or you can even enlarge it to include another box (if it doesn't contain it already)
   void include_box(const BoundingBox& box)
   {
      for(unsigned int i=0; i<3; ++i){
         if(box.xmin[i]<xmin[i]) xmin[i]=box.xmin[i];
         if(box.xmax[i]>xmax[i]) xmax[i]=box.xmax[i];
      }
   }

   // increases the bounding box by epsilon in each direction: useful for dealing with rounding errors!
   void enlarge(float epsilon)
   {
      xmin-=Vec3f(epsilon,epsilon,epsilon);
      xmax+=Vec3f(epsilon,epsilon,epsilon);
   }

   // return if the ray intersects the bounding box within the range [tmin,tmax];
   // the first intersection value is returned in t.
   bool intersect(const Ray& ray, float tmin, float tmax, float& t) const
   {
      // loop over axes, shrinking (tmin,tmax) by intersecting ray with each slab
      for(int axis=0; axis<3; ++axis){
         if(ray.direction[axis]==0){ // check to see if the ray is parallel to this slab
            // if the ray doesn't start in the slab it's parallel to, it can't intersect the box
            if(ray.origin[axis]<xmin[axis] || ray.origin[axis]>xmax[axis]) return false;
         }else{ // if not, we can look for intersections
            float t0=-(ray.origin[axis]-xmin[axis])/ray.direction[axis],
                  t1=-(ray.origin[axis]-xmax[axis])/ray.direction[axis];
            if(t1<t0) std::swap(t0,t1);
            if(t0>tmin) tmin=t0;
            if(t1<tmax) tmax=t1;
            if(tmin>tmax) return false; // if the interval is now empty, there's no intersection
         }
      }
      t=tmin;
      return true;
   }
};

// an IO operator so you can more easily dump out a box when debugging, e.g. std::cout<<box
inline std::ostream &operator<<(std::ostream &out, const BoundingBox& box)
{
   out<<"("<<box.xmin<<" ~ "<<box.xmax<<")";
   return out;
}

#endif
