#include "raytracer.h"

Vec3f RayTracer::
trace_ray(const Ray& ray, float tmin, float tmax, int depth_left) const
{
   float t;
   Vec3f normal;
   Material material;

   // find the first intesection with geometry in the scene
   if(shape.intersect(ray, tmin, tmax, t, normal, material)){
      // now compute the color, starting with any direct emission from the material
      Vec3f color(material.emission_color);
      // determine the location of the intersection
      Vec3f x=ray.origin+t*ray.direction;
      // handle diffuse component from lighting if it's nonzero
      if(material.diffuse_color.nonzero()){
         // we need to know how much light is streaming in: first off, from undirected ambient light
         Vec3f incoming_light=lighting.ambient;
         // then loop over the directed lights to see what they contribute
         for(unsigned int i=0; i<lighting.directed_light.size(); ++i){
            Vec3f light_direction, light_color;
            float light_distance;
            lighting.directed_light[i]->evaluate(x, light_direction, light_color, light_distance);
            float cosine_factor=dot(light_direction, normal);
            if(cosine_factor>0){ // only do any work if there's a chance this object can see the light
               // shoot a ray towards the light to check if any geometry is blocking the way
               Ray shadow_ray(x, light_direction);
               if(!shape.quick_intersect(shadow_ray, epsilon, light_distance)){
                  // the light is not obscured, so add its contribution to lighting at this point
                  incoming_light+=light_color*cosine_factor;
               }
            }
         }
         // scale the incoming light by the diffuse material property to get this contribution to final color.
         color+=incoming_light*material.diffuse_color;
      }
      // check for mirror reflection component (if there is a reflection, and we're allowed to recurse any further)
      if(material.mirror_color.nonzero() && depth_left>0){
         // form the mirror reflection direction
         Ray reflection_ray(x, ray.direction-(2*dot(ray.direction,normal))*normal);
         // and recursively trace a reflection ray to get that color, scaled by the material property.
         color+=trace_ray(reflection_ray, epsilon, FLT_MAX, depth_left-1)*material.mirror_color;
      }
      assert(color==color); // guard against NaN's that might have crept in due to a bug
      // and finish
      return color;

   }else{ // if there was no intersection at all, return a default black
      return Vec3f(1,1,1);
   }
}
