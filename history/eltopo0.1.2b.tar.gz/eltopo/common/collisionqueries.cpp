
#include "collisionqueries.h"
#include <limits>

static const double UNINITIALIZED_DOUBLE = 0x0F;

//
// Local structs
// 

// ---------------------------------------------------------
///
/// Abstract struct, wrapper for a scalar function whose roots we will search for.
///
// ---------------------------------------------------------

struct RootFinderFunction
{
   virtual ~RootFinderFunction() {}
   virtual double eval( double t ) const = 0;
};

// ---------------------------------------------------------
///
/// Wrapper for a generic cubic function.
///
// ---------------------------------------------------------

struct CubicFunction : public RootFinderFunction
{
   double A, B, C, D;
   CubicFunction( double in_A, double in_B, double in_C, double in_D ) :
   A(in_A),
   B(in_B),
   C(in_C),
   D(in_D)
   {}
   
   virtual ~CubicFunction() {}
   
   inline double eval( double t ) const
   {
      return A*t*t*t + B*t*t + C*t + D;
   }
};

// ---------------------------------------------------------
///
/// Wrapper for a the scalar function f(t) = point_triangle_proximity(t) - epsilon
///
// ---------------------------------------------------------

struct PointTriangleProximityFunction : public RootFinderFunction
{
   Vec3d p, t0, t1, t2;
   Vec3d pnew, tnew0, tnew1, tnew2;
   double epsilon;
   
   PointTriangleProximityFunction() :
      p(UNINITIALIZED_DOUBLE), t0(UNINITIALIZED_DOUBLE), t1(UNINITIALIZED_DOUBLE), t2(UNINITIALIZED_DOUBLE),
      pnew(UNINITIALIZED_DOUBLE), tnew0(UNINITIALIZED_DOUBLE), tnew1(UNINITIALIZED_DOUBLE), tnew2(UNINITIALIZED_DOUBLE),
      epsilon(UNINITIALIZED_DOUBLE)
   {}
   
   virtual ~PointTriangleProximityFunction() {}
   
   inline double eval( double t ) const
   {
      Vec3d pt = (1-t)*p + t*pnew;
      Vec3d t0t = (1-t)*t0 + t*tnew0;
      Vec3d t1t = (1-t)*t1 + t*tnew1;
      Vec3d t2t = (1-t)*t2 + t*tnew2;
      double distance;
      check_point_triangle_proximity( pt, t0t, t1t, t2t, distance );
      
      return (distance - epsilon);
   }
};

// ---------------------------------------------------------
///
/// Wrapper for a the scalar function f(t) = edge_edge_proximity(t) - epsilon
///
// ---------------------------------------------------------

struct EdgeEdgeProximityFunction : public RootFinderFunction
{
   EdgeEdgeProximityFunction() : 
      x0(UNINITIALIZED_DOUBLE), x1(UNINITIALIZED_DOUBLE), x2(UNINITIALIZED_DOUBLE), x3(UNINITIALIZED_DOUBLE),
      xnew0(UNINITIALIZED_DOUBLE), xnew1(UNINITIALIZED_DOUBLE), xnew2(UNINITIALIZED_DOUBLE), xnew3(UNINITIALIZED_DOUBLE),
      epsilon(UNINITIALIZED_DOUBLE)
   {}
      
   Vec3d x0, x1, x2, x3;
   Vec3d xnew0, xnew1, xnew2, xnew3;
   double epsilon;
   
   virtual ~EdgeEdgeProximityFunction() {}
   
   inline double eval( double t ) const
   {
      Vec3d x0t = (1-t)*x0 + t*xnew0;
      Vec3d x1t = (1-t)*x1 + t*xnew1;
      Vec3d x2t = (1-t)*x2 + t*xnew2;
      Vec3d x3t = (1-t)*x3 + t*xnew3;
      double distance;
      check_edge_edge_proximity( x0t, x1t, x2t, x3t, distance );
      
      return (distance - epsilon);
   }
};


// ---------------------------------------------------------
///
/// Signed volume of a tetrahedron
///
// ---------------------------------------------------------

double signed_volume(const Vec3d &x0, const Vec3d &x1, const Vec3d &x2, const Vec3d &x3)
{
   // Equivalent to triple(x1-x0, x2-x0, x3-x0), six times the signed volume of the tetrahedron.
   // But, for robustness, we want the result (up to sign) to be independent of the ordering.
   // And want it as accurate as possible...
   // But all that stuff is hard, so let's just use the common assumption that all coordinates are >0,
   // and do something reasonably accurate in fp.

   // This formula does almost four times too much multiplication, but if the coordinates are non-negative
   // it suffers in a minimal way from cancellation error.
   return ( x0[0]*(x1[1]*x3[2]+x3[1]*x2[2]+x2[1]*x1[2])
           +x1[0]*(x2[1]*x3[2]+x3[1]*x0[2]+x0[1]*x2[2])
           +x2[0]*(x3[1]*x1[2]+x1[1]*x0[2]+x0[1]*x3[2])
           +x3[0]*(x1[1]*x2[2]+x2[1]*x0[2]+x0[1]*x1[2]) )

        - ( x0[0]*(x2[1]*x3[2]+x3[1]*x1[2]+x1[1]*x2[2])
           +x1[0]*(x3[1]*x2[2]+x2[1]*x0[2]+x0[1]*x3[2])
           +x2[0]*(x1[1]*x3[2]+x3[1]*x0[2]+x0[1]*x1[2])
           +x3[0]*(x2[1]*x1[2]+x1[1]*x0[2]+x0[1]*x2[2]) );
}

// ---------------------------------------------------------
///
/// Compute all proximities between an edge and a triangle and report the minimum
///
// ---------------------------------------------------------

double lowest_triangle_edge_proximity( const Vec3d &t0, const Vec3d &t1, const Vec3d &t2, 
                                       const Vec3d &e0, const Vec3d &e1 )
{
   double min_dist = 1e30;

   double curr_dist;
   check_point_triangle_proximity( e0, t0, t1, t2, curr_dist );
   min_dist = min( min_dist, curr_dist );
   check_point_triangle_proximity( e1, t0, t1, t2, curr_dist );
   min_dist = min( min_dist, curr_dist );

   check_edge_edge_proximity( e0, e1, t0, t1, curr_dist );
   min_dist = min( min_dist, curr_dist );
   check_edge_edge_proximity( e0, e1, t1, t2, curr_dist );
   min_dist = min( min_dist, curr_dist );
   check_edge_edge_proximity( e0, e1, t2, t0, curr_dist );
   min_dist = min( min_dist, curr_dist );

   return min_dist;
}


// ---------------------------------------------------------
///
/// Return true if triangle (x1,x2,x3) intersects segment (x4,x5)
///
// ---------------------------------------------------------

static bool triangle_intersects_segment(const Vec3d &x1, const Vec3d &x2, const Vec3d &x3, 
                                        const Vec3d &x4, const Vec3d &x5,
                                        double tolerance, bool verbose, bool& degenerate )
{
   static const double machine_epsilon = 1e-14;
   
   degenerate = false;
   
   double d=signed_volume(x1, x2, x3, x5);
   double e=-signed_volume(x1, x2, x3, x4);
   
   if ( verbose )
   {
      std::cout << "d: " << d << std::endl;
      std::cout << "e: " << e << std::endl;
   }
   
   if ( ( fabs(d) < machine_epsilon ) || ( fabs(e) < machine_epsilon ) )
   {
      degenerate = true;
   }
   
   if((d>0) ^ (e>0))
   {
      // if the segment is completely on one side of the triangle but closer than tolerance, report intersection
      if ( lowest_triangle_edge_proximity( x1, x2, x3, x4, x5 ) < tolerance )
      {
         if ( verbose ) { std::cout << "edge is totally on one side but closer than tolerance" << std::endl; }
         return true;
      }
      return false;
   }
   
   // note: using the triangle edges in the first two spots guarantees the same floating point result (up to sign)
   // if we transpose the triangle vertices -- e.g. testing an adjacent triangle -- so this triangle-line test is
   // watertight.
   double a=signed_volume(x2, x3, x4, x5);
   double b=signed_volume(x3, x1, x4, x5);
   double c=signed_volume(x1, x2, x4, x5);
   
   if ( verbose )
   {
      std::cout << "a: " << a << std::endl;
      std::cout << "b: " << b << std::endl;
      std::cout << "c: " << c << std::endl;
   }
   
   double sum_abc=a+b+c;
   
   if ( verbose ) std::cout << "sum_abc: " << sum_abc << std::endl;
   
   if( fabs(sum_abc) < machine_epsilon )
   {
      degenerate = true;
      return false;            // degenerate situation
   }
   
   double sum_de=d+e;
   
   if ( verbose ) std::cout << "sum_de: " << sum_de << std::endl;
   
   if( fabs(sum_de) < machine_epsilon )
   {
      degenerate = true;
      return false; // degenerate situation
   }

   
   if ( ( fabs(a) < machine_epsilon ) || ( fabs(b) < machine_epsilon ) || (fabs(c) < machine_epsilon) )
   {
      degenerate = true;
   }

   
   if((a>0) ^ (b>0))
   {
      // if the segment is completely on one side of the triangle but closer than tolerance, report intersection
      if ( lowest_triangle_edge_proximity( x1, x2, x3, x4, x5 ) < tolerance )
      {
         if ( verbose ) 
         { 
            std::cout << "edge is totally on one side but closer than tolerance" << std::endl; 
            std::cout << "degenerate: " << degenerate << std::endl;
         }
         return true;
      }

      return false;
   }
   
   if((a>0) ^ (c>0))
   {
      // if the segment is completely on one side of the triangle but closer than tolerance, report intersection
      if ( lowest_triangle_edge_proximity( x1, x2, x3, x4, x5 ) < tolerance )
      {
         return true;
      }
      
      return false;
   }
   
   double over_abc=1/sum_abc;
   a*=over_abc;
   b*=over_abc;
   c*=over_abc;
         
   double over_de=1/sum_de;
   d*=over_de;
   e*=over_de;
   
   if ( verbose ) 
   {
      std::cout << "normalized coords: " << a << " " << b << " " << c << " " << d << " " << e << std::endl;
   }
   
   return true;
}

// ---------------------------------------------------------
///
/// Return true if triangle (xtri0,xtri1,xtri2) intersects segment (xedge0, xedge1), within the specified tolerance.
/// If degenerate_counts_as_intersection is true, this function will return true in a degenerate situation.
///
// ---------------------------------------------------------

bool check_edge_triangle_intersection(const Vec3d &xedge0, const Vec3d &xedge1,
                                      const Vec3d &xtri0, const Vec3d &xtri1, const Vec3d &xtri2,
                                      double tolerance, bool degenerate_counts_as_intersection, bool verbose )
{
   bool is_degenerate;
   if ( triangle_intersects_segment( xtri0, xtri1, xtri2, xedge0, xedge1, tolerance, verbose, is_degenerate ) )
   {
      if ( is_degenerate )
      {
         if ( degenerate_counts_as_intersection )
         {
            return true;
         }
      }
      else
      {
         return true;
      }
   }
   
   return false;
}


void check_point_edge_proximity(bool update, const Vec3d &x0, const Vec3d &x1, const Vec3d &x2,
                                double &distance)
{
   Vec3d dx(x2-x1);
   double m2=mag2(dx);
   // find parameter value of closest point on segment
   double s=clamp(dot(x2-x0, dx)/m2, 0., 1.);
   // and find the distance
   if(update){
      distance=min(distance, dist(x0,s*x1+(1-s)*x2));
   }else{
      distance=dist(x0,s*x1+(1-s)*x2);
   }
}

// normal is from 1-2 towards 0, unless normal_multiplier<0
void check_point_edge_proximity(bool update, const Vec3d &x0, const Vec3d &x1, const Vec3d &x2,
                                double &distance, double &s, Vec3d &normal, double normal_multiplier)
{
   Vec3d dx(x2-x1);
   double m2=mag2(dx);
   if(update){
      // find parameter value of closest point on segment
      double this_s=clamp(dot(x2-x0, dx)/m2, 0., 1.);
      // and find the distance
      Vec3d this_normal=x0-(this_s*x1+(1-this_s)*x2);
      double this_distance=mag(this_normal);
      if(this_distance<distance){
         s=this_s;
         distance=this_distance;
         normal=(normal_multiplier/(this_distance+1e-30))*this_normal;
      }
   }else{
      // find parameter value of closest point on segment
      s=clamp(dot(x2-x0, dx)/m2, 0., 1.);
      // and find the distance
      normal=x0-(s*x1+(1-s)*x2);
      distance=mag(normal);
      normal*=normal_multiplier/(distance+1e-30);
   }
}

void check_point_edge_proximity(bool update, const Vec2d &x0, const Vec2d &x1, const Vec2d &x2,
                                double &distance)
{
   Vec2d dx(x2-x1);
   double m2=mag2(dx);
   // find parameter value of closest point on segment
   double s=clamp(dot(x2-x0, dx)/m2, 0., 1.);
   // and find the distance
   if(update){
      distance=min(distance, dist(x0,s*x1+(1-s)*x2));
   }else{
      distance=dist(x0,s*x1+(1-s)*x2);
   }
}

// normal is from 1-2 towards 0, unless normal_multiplier<0
void check_point_edge_proximity(bool update, const Vec2d &x0, const Vec2d &x1, const Vec2d &x2,
                                double &distance, double &s, Vec2d &normal, double normal_multiplier)
{
   Vec2d dx(x2-x1);
   double m2=mag2(dx);
   if(update){
      // find parameter value of closest point on segment
      double this_s=clamp(dot(x2-x0, dx)/m2, 0., 1.);
      // and find the distance
      Vec2d this_normal=x0-(this_s*x1+(1-this_s)*x2);
      double this_distance=mag(this_normal);
      if(this_distance<distance){
         s=this_s;
         distance=this_distance;
         normal=(normal_multiplier/(this_distance+1e-30))*this_normal;
      }
   }else{
      // find parameter value of closest point on segment
      s=clamp(dot(x2-x0, dx)/m2, 0., 1.);
      // and find the distance
      normal=x0-(s*x1+(1-s)*x2);
      distance=mag(normal);
      normal*=normal_multiplier/(distance+1e-30);
   }
}

void check_edge_edge_proximity(const Vec3d &x0, const Vec3d &x1, const Vec3d &x2, const Vec3d &x3, double &distance)
{
   // let's do it the QR way for added robustness
   Vec3d x01=x0-x1;
   double r00=mag(x01)+1e-30;
   x01/=r00;
   Vec3d x32=x3-x2;
   double r01=dot(x32,x01);
   x32-=r01*x01;
   double r11=mag(x32)+1e-30;
   x32/=r11;
   Vec3d x31=x3-x1;
   double s2=dot(x32,x31)/r11;
   double s0=(dot(x01,x31)-r01*s2)/r00;
   // check if we're in range
   if(s0<0){
      if(s2<0){
         // check both x1 against 2-3 and 3 against 0-1
         check_point_edge_proximity(false, x1, x2, x3, distance);
         check_point_edge_proximity(true, x3, x0, x1, distance);
      }else if(s2>1){
         // check both x1 against 2-3 and 2 against 0-1
         check_point_edge_proximity(false, x1, x2, x3, distance);
         check_point_edge_proximity(true, x2, x0, x1, distance);
      }else{
         s0=0;
         // check x1 against 2-3
         check_point_edge_proximity(false, x1, x2, x3, distance);
      }
   }else if(s0>1){
      if(s2<0){
         // check both x0 against 2-3 and 3 against 0-1
         check_point_edge_proximity(false, x0, x2, x3, distance);
         check_point_edge_proximity(true, x3, x0, x1, distance);
      }else if(s2>1){
         // check both x0 against 2-3 and 2 against 0-1
         check_point_edge_proximity(false, x0, x2, x3, distance);
         check_point_edge_proximity(true, x2, x0, x1, distance);
      }else{
         s0=1;
         // check x0 against 2-3
         check_point_edge_proximity(false, x0, x2, x3, distance);
      }
   }else{
      if(s2<0){
         s2=0;
         // check x3 against 0-1
         check_point_edge_proximity(false, x3, x0, x1, distance);
      }else if(s2>1){
         s2=1;
         // check x2 against 0-1
         check_point_edge_proximity(false, x2, x0, x1, distance);
      }else{ // we already got the closest points!
         distance=dist(s2*x2+(1-s2)*x3, s0*x0+(1-s0)*x1);
      }
   }
}

// find distance between 0-1 and 2-3, with barycentric coordinates for closest points, and
// a normal that points from 0-1 towards 2-3 (unreliable if distance==0 or very small)
void check_edge_edge_proximity(const Vec3d &x0, const Vec3d &x1, const Vec3d &x2, const Vec3d &x3,
                               double &distance, double &s0, double &s2, Vec3d &normal)
{
   // let's do it the QR way for added robustness
   Vec3d x01=x0-x1;
   double r00=mag(x01)+1e-30;
   x01/=r00;
   Vec3d x32=x3-x2;
   double r01=dot(x32,x01);
   x32-=r01*x01;
   double r11=mag(x32)+1e-30;
   x32/=r11;
   Vec3d x31=x3-x1;
   s2=dot(x32,x31)/r11;
   s0=(dot(x01,x31)-r01*s2)/r00;
   // check if we're in range
   if(s0<0){
      if(s2<0){
         // check both x1 against 2-3 and 3 against 0-1
         check_point_edge_proximity(false, x1, x2, x3, distance, s2, normal, -1.);
         check_point_edge_proximity(true, x3, x0, x1, distance, s0, normal, 1.);
      }else if(s2>1){
         // check both x1 against 2-3 and 2 against 0-1
         check_point_edge_proximity(false, x1, x2, x3, distance, s2, normal, -1.);
         check_point_edge_proximity(true, x2, x0, x1, distance, s0, normal, 1.);
      }else{
         s0=0;
         // check x1 against 2-3
         check_point_edge_proximity(false, x1, x2, x3, distance, s2, normal, -1.);
      }
   }else if(s0>1){
      if(s2<0){
         // check both x0 against 2-3 and 3 against 0-1
         check_point_edge_proximity(false, x0, x2, x3, distance, s2, normal, -1.);
         check_point_edge_proximity(true, x3, x0, x1, distance, s0, normal, 1.);
      }else if(s2>1){
         // check both x0 against 2-3 and 2 against 0-1
         check_point_edge_proximity(false, x0, x2, x3, distance, s2, normal, -1.);
         check_point_edge_proximity(true, x2, x0, x1, distance, s0, normal, 1.);
      }else{
         s0=1;
         // check x0 against 2-3
         check_point_edge_proximity(false, x0, x2, x3, distance, s2, normal, -1.);
      }
   }else{
      if(s2<0){
         s2=0;
         // check x3 against 0-1
         check_point_edge_proximity(false, x3, x0, x1, distance, s0, normal, 1.);
      }else if(s2>1){
         s2=1;
         // check x2 against 0-1
         check_point_edge_proximity(false, x2, x0, x1, distance, s0, normal, 1.);
      }else{ // we already got the closest points!
         normal=(s2*x2+(1-s2)*x3)-(s0*x0+(1-s0)*x1);
         distance=mag(normal);
         if(distance>0) normal/=distance;
         else{
            normal=cross(x1-x0, x3-x2);
            normal/=mag(normal)+1e-300;
         }
      }
   }
}

void check_point_triangle_proximity(const Vec3d &x0, const Vec3d &x1, const Vec3d &x2, const Vec3d &x3,
                                    double &distance)
{
   // do it the QR way for added robustness
   Vec3d x13=x1-x3;
   double r00=mag(x13)+1e-30;
   x13/=r00;
   Vec3d x23=x2-x3;
   double r01=dot(x23,x13);
   x23-=r01*x13;
   double r11=mag(x23)+1e-30;
   x23/=r11;
   Vec3d x03=x0-x3;
   double s2=dot(x23,x03)/r11;
   double s1=(dot(x13,x03)-r01*s2)/r00;
   double s3=1-s1-s2;
   // check if we are in range
   if(s1>=0 && s2>=0 && s3>=0){
      distance=dist(x0, s1*x1+s2*x2+s3*x3);
   }else{
      if(s1>0){ // rules out edge 2-3
         check_point_edge_proximity(false, x0, x1, x2, distance);
         check_point_edge_proximity(true, x0, x1, x3, distance);
      }else if(s2>0){ // rules out edge 1-3
         check_point_edge_proximity(false, x0, x1, x2, distance);
         check_point_edge_proximity(true, x0, x2, x3, distance);
      }else{ // s3>0: rules out edge 1-2
         check_point_edge_proximity(false, x0, x2, x3, distance);
         check_point_edge_proximity(true, x0, x1, x3, distance);
      }
   }
}

// find distance between 0 and 1-2-3, with barycentric coordinates for closest point, and
// a normal that points from 1-2-3 towards 0 (unreliable if distance==0 or very small)
void check_point_triangle_proximity(const Vec3d &x0, const Vec3d &x1, const Vec3d &x2, const Vec3d &x3,
                                    double &distance, double &s1, double &s2, double &s3, Vec3d &normal)
{
   // do it the QR way for added robustness
   Vec3d x13=x1-x3;
   double r00=mag(x13)+1e-30;
   x13/=r00;
   Vec3d x23=x2-x3;
   double r01=dot(x23,x13);
   x23-=r01*x13;
   double r11=mag(x23)+1e-30;
   x23/=r11;
   Vec3d x03=x0-x3;
   s2=dot(x23,x03)/r11;
   s1=(dot(x13,x03)-r01*s2)/r00;
   s3=1-s1-s2;
   // check if we are in range
   if(s1>=0 && s2>=0 && s3>=0){
      normal=x0-(s1*x1+s2*x2+s3*x3);
      distance=mag(normal);
      if(distance>0) normal/=distance;
      else{
         normal=cross(x2-x1, x3-x1);
         normal/=mag(normal)+1e-300;
      }
   }else{
      double s, d;
      if(s1>0){ // rules out edge 2-3
         check_point_edge_proximity(false, x0, x1, x2, distance, s, normal, 1.);
         s1=s; s2=1-s; s3=0; d=distance;
         check_point_edge_proximity(true, x0, x1, x3, distance, s, normal, 1.);
         if(distance<d){
            s1=s; s2=0; s3=1-s;
         }
      }else if(s2>0){ // rules out edge 1-3
         check_point_edge_proximity(false, x0, x1, x2, distance, s, normal, 1.);
         s1=s; s2=1-s; s3=0; d=distance;
         check_point_edge_proximity(true, x0, x2, x3, distance, s, normal, 1.);
         if(distance<d){
            s1=0; s2=s; s3=1-s; d=distance;
         }
      }else{ // s3>0: rules out edge 1-2
         check_point_edge_proximity(false, x0, x2, x3, distance, s, normal, 1.);
         s1=0; s2=s; s3=1-s; d=distance;
         check_point_edge_proximity(true, x0, x1, x3, distance, s, normal, 1.);
         if(distance<d){
            s1=s; s2=0; s3=1-s;
         }
      }
   }
}


// ---------------------------------------------------------
///
/// Use a hybrid bisection/secant solver to find roots of the given function. 
///
// ---------------------------------------------------------

void find_roots( const RootFinderFunction* func,
                 const std::vector<double>& interval_times, 
                 double convergence_tol,
                 double root_crossing_tol,
                 std::vector<double>& root_times,
                 bool verbose )
{
   
   root_times.clear();
   
   std::vector<double> interval_values;
   for ( unsigned int i = 0; i < interval_times.size(); ++i )
   {
      interval_values.push_back( func->eval( interval_times[i] ) );
      if ( verbose ) 
      { 
         std::cout << "pre-root-finding interval time: " << interval_times[i] << ", value: " << interval_values[i] << std::endl; 
      }
   }

   
   // first look for interval endpoints that are close enough to zero, without a sign change
   for ( unsigned int i=0; i<interval_times.size(); ++i )
   {
      if( interval_values[i]==0 )
      {
         root_times.push_back(interval_times[i]);
         if ( verbose ) { std::cout << "interval boundary time: " << interval_times[i] << " and value: " << interval_values[i] << std::endl; }
      }
      else if( std::fabs(interval_values[i]) < convergence_tol )
      {
         if(  (i==0 || (interval_values[i-1]>=0 && interval_values[i]>=0) || (interval_values[i-1]<=0 && interval_values[i]<=0))    
            &&(i==interval_times.size()-1 || (interval_values[i+1]>=0 && interval_values[i]>=0) || (interval_values[i+1]<=0 && interval_values[i]<=0)))
         {
            root_times.push_back(interval_times[i]);
            if ( verbose ) { std::cout << "interval boundary time: " << interval_times[i] << " and value: " << interval_values[i] << std::endl; }
         }
      }
   }
   
   
   // search in intervals with a sign change
   for ( unsigned int i=1; i<interval_times.size(); ++i )
   {
      double tlo=interval_times[i-1], thi=interval_times[i], tmid;
      double vlo=interval_values[i-1], vhi=interval_values[i], vmid;
      if((vlo<0 && vhi>0) || (vlo>0 && vhi<0))
      {
         // start off with secant approximation (in case the cubic is actually linear)
         double alpha=vhi/(vhi-vlo);
         tmid=alpha*tlo+(1-alpha)*thi;
         int iteration;
         const int max_iteration = 100;
         for(iteration=0; iteration<max_iteration; ++iteration)
         {  
            vmid = func->eval( tmid );
            
            if(std::fabs(vmid) < root_crossing_tol ) { break; }
            
            if((vlo<0 && vmid>0) || (vlo>0 && vmid<0)){ // if sign change between lo and mid
               thi=tmid;
               vhi=vmid;
            }else{ // otherwise sign change between hi and mid
               tlo=tmid;
               vlo=vmid;
            }
            
            if(iteration%2) alpha=0.5; // sometimes go with bisection to guarantee we make progress
            else alpha=vhi/(vhi-vlo); // other times go with secant to hopefully get there fast
            tmid=alpha*tlo+(1-alpha)*thi;
         }
                 
         if ( iteration == max_iteration )
         {
            std::cout << "failed to converge to tolerance: " << root_crossing_tol << std::endl;
            std::cout << "vlo: " << vlo << std::endl;
            std::cout << "vmid: " << func->eval( tmid ) << std::endl;
            std::cout << "vhi: " << vhi << std::endl;
         }
         
         assert( iteration < max_iteration );
         
         if ( verbose )
         {
            std::cout << "sign change root: " << tmid << ", value at root: " << vmid << std::endl;
         }
         
         root_times.push_back(tmid);
         
      }
   }
   
   sort( root_times.begin(), root_times.end() );
}


// ---------------------------------------------------------
///
/// Get critical points for the given cubic in the inverval [0,1].
///
// ---------------------------------------------------------

void get_cubic_intervals( double A, double B, double C, double D, 
                          double interval_tol, std::vector<double> &interval_times, bool verbose )
{
   interval_times.clear();
   
   // find intervals to check, or just solve it if it reduces to a quadratic =============================

   double discriminant=B*B-3*A*C; // of derivative of cubic, 3*A*t^2+2*B*t+C, divided by 4 for convenience
   
   if ( verbose ) 
   {
      std::cout << "discriminant: " << discriminant << std::endl;
   }
   
   if(discriminant<=0)  // monotone cubic: only one root in [0,1] possible
   { 
      // so we just 
      interval_times.push_back(0);
      interval_times.push_back(1);
   }else{ // positive discriminant, B!=0
      if(A==0) // the cubic is just a quadratic, B*t^2+C*t+D ========================================
      {
         discriminant=C*C-4*B*D; // of the quadratic
         
         if ( verbose ) { std::cout << "quadratic discriminant: " << discriminant << std::endl; }
         
         interval_times.push_back(0);
         
         if(discriminant<=0)
         {
            double t=-C/(2*B);
            if(t>=-interval_tol && t<=1+interval_tol)
            {
               // --- critical point
               t=clamp(t, 0., 1.);
               interval_times.push_back(t);
            }
         }
         else // two separate real roots
         {
            double t0, t1;
            if(C>0) t0=(-C-std::sqrt(discriminant))/(2*B);
            else    t0=(-C+std::sqrt(discriminant))/(2*B);
            t1=D/(B*t0);
            if(t1<t0) swap(t0,t1);
            
            if ( verbose )
            {
               std::cout << "t0 = " << t0 << std::endl;
               std::cout << "t1 = " << t1 << std::endl;
            }
            
            if(t0>=-interval_tol && t0<=1+interval_tol) interval_times.push_back(clamp(t0, 0., 1.));
            if(t1>=-interval_tol && t1<=1+interval_tol) add_unique(interval_times, clamp(t1, 0., 1.));
         }
         
         interval_times.push_back(1);
         
      }
      else
      { 
         // cubic is not monotone: divide up [0,1] accordingly =====================================
         double t0, t1;
         if(B>0) t0=(-B-std::sqrt(discriminant))/(3*A);
         else    t0=(-B+std::sqrt(discriminant))/(3*A);
         t1=C/(3*A*t0);
         if(t1<t0) swap(t0,t1);
         interval_times.push_back(0);
         
         if ( verbose )
         {
            std::cout << "non-monotone cubic t0: " << t0 << std::endl;
            std::cout << "non-monotone cubic t1: " << t1 << std::endl;
         }
         
         if(t0>0 && t0<1)
            interval_times.push_back(t0);
         if(t1>0 && t1<1)
            interval_times.push_back(t1);
         
         interval_times.push_back(1);
      }
   }
   
}
   

// ---------------------------------------------------------
///
/// Find times at which the given tet has zero volume
///
// ---------------------------------------------------------

void find_coplanarity_times(const Vec3d &x0, const Vec3d &x1, const Vec3d &x2, const Vec3d &x3,
                            const Vec3d &xnew0, const Vec3d &xnew1, const Vec3d &xnew2, const Vec3d &xnew3,
                            std::vector<double> &possible_times, bool verbose )
{
   
   possible_times.clear();
   // cubic coefficients, A*t^3+B*t^2+C*t+D (for t in [0,1])
   Vec3d x03=x0-x3, x13=x1-x3, x23=x2-x3;
   Vec3d v03=(xnew0-xnew3)-x03, v13=(xnew1-xnew3)-x13, v23=(xnew2-xnew3)-x23;
   double A=triple(v03,v13,v23),
          B=triple(x03,v13,v23)+triple(v03,x13,v23)+triple(v03,v13,x23),
          C=triple(x03,x13,v23)+triple(x03,v13,x23)+triple(v03,x13,x23),
          D=triple(x03,x13,x23);   
   
   // If tol is too low, we might miss times where the proximity is below collision_epsilon (especially dangerous at t=1). 
   // If tol is too high, we might think we have a root too early, and proximity at that time might be over collision_epsilon, whereas at the true root, the proximity might be below collision_epsilon.
   
   // If a possible root lies just outside [0,1], clamp it and check it.  This tol tells us how far outside [0,1] we will check.
   const double interval_tol = 1e-2;
     
   // When we find a critical point, we check to see if it's "close enough" to zero to check.  This tolerance tells us how close is "close enough"
   const double convergence_tol= 1e-5 * 1.0/12.0 * (mag(x0) + mag(x1) + mag(x2) + mag(x3) + 
                                                    mag(xnew0) + mag(xnew1) + mag(xnew2) + mag(xnew3) + 
                                                    mag(xnew0-x0) + mag(xnew1-x1) + mag(xnew2-x2) + mag(xnew3-x3)); 
   
   // When running the bisection/secant root finder, this tolerance tells us when to stop.  Much stricter than convergence_tol 
   // because we know the function crosses zero at some point in our search interval and we want to get really close to that point.
   // In fact this should probably be close to machine epsilon...
   const double crossing_root_tol = 1e-15;  //* convergence_tol;
   
   if ( verbose ) 
   {
      std::cout << "cubic solve..." << std::endl;
      std::cout << "A: " << A << std::endl;
      std::cout << "B: " << B << std::endl;
      std::cout << "C: " << C << std::endl;      
      std::cout << "D: " << D << std::endl;
      
      std::cout << "convergence_tol: " << convergence_tol << std::endl;
      std::cout << "crossing_root_tol: " << crossing_root_tol << std::endl;
   }
      
   std::vector<double> interval_times;
   get_cubic_intervals( A, B, C, D, interval_tol, interval_times, verbose );
   
   CubicFunction func( A, B, C, D );
   
   find_roots( &func, interval_times, convergence_tol, crossing_root_tol, possible_times, verbose );

}


// ---------------------------------------------------------
///
/// Find times at which edge-edge proximity is equal to the given collision epsilon
///
// ---------------------------------------------------------

void find_edge_edge_proximity_equals_epsilon_times(const Vec3d &x0, const Vec3d &x1, const Vec3d &x2, const Vec3d &x3,
                                                   const Vec3d &xnew0, const Vec3d &xnew1, const Vec3d &xnew2, const Vec3d &xnew3,
                                                   double collision_epsilon,
                                                   std::vector<double> &root_times, bool verbose )
{
   
   //
   // First use the cubic solver to find intervals
   //
   
   // cubic coefficients, A*t^3+B*t^2+C*t+D (for t in [0,1])
   Vec3d x03=x0-x3, x13=x1-x3, x23=x2-x3;
   Vec3d v03=(xnew0-xnew3)-x03, v13=(xnew1-xnew3)-x13, v23=(xnew2-xnew3)-x23;
   double A=triple(v03,v13,v23),
   B=triple(x03,v13,v23)+triple(v03,x13,v23)+triple(v03,v13,x23),
   C=triple(x03,x13,v23)+triple(x03,v13,x23)+triple(v03,x13,x23),
   D=triple(x03,x13,x23);   
   
   // If a possible root lies just outside [0,1], clamp it and check it.  This tol tells us how far outside [0,1] we will check.
   const double interval_tol = 1e-2;
   
   std::vector<double> interval_times;
   
   if ( verbose ) { std::cout << " ----------- finding cubic intervals ----------- " << std::endl; }
   
   get_cubic_intervals( A, B, C, D, interval_tol, interval_times, verbose );
   
   //
   // We also need to get the roots of the cubic as intervals. The proximity function is always nonnegative, so can't detect
   // trajectories where the two edges pass through each other if they start and end with proximity > epsilon.
   //
   
   std::vector<double> coplanarity_times;
   
   if ( verbose ) { std::cout << " ----------- finding cubic roots ----------- " << std::endl; }
   
   find_coplanarity_times( x0, x1, x2, x3, xnew0, xnew1, xnew2, xnew3,
                          coplanarity_times, verbose );
   
   for ( unsigned int i = 0; i <  coplanarity_times.size(); ++i )
   {
      add_unique( interval_times, coplanarity_times[i] );
   }
   
   sort( interval_times.begin(), interval_times.end() );
   
   //
   // Now use our general root solver to find points where f(x) = [proximity - eps] crosses zero.
   //
   
   EdgeEdgeProximityFunction func;
   func.x0 = x0;        func.x1 = x1;        func.x2 = x2;        func.x3 = x3;
   func.xnew0 = xnew0;  func.xnew1 = xnew1;  func.xnew2 = xnew2;  func.xnew3 = xnew3;
   func.epsilon = collision_epsilon;
   
   root_times.clear();
   
   const double interval_bdry_tol = 1e-14;
   const double zero_cross_tol = 1e-15;
   
   if ( verbose ) { std::cout << " ----------- finding function roots ----------- " << std::endl; }
   
   find_roots( &func, interval_times, interval_bdry_tol, zero_cross_tol, root_times, verbose );
   
   if ( verbose ) 
   {
      for ( unsigned int i = 0; i < root_times.size(); ++i )
      {
         std::cout << "root time: " << root_times[i] << ", value: " << func.eval(root_times[i]) << std::endl;
      }
         
      std::cout << " ----------- done finding function roots ----------- " << std::endl; 
   }
   
}


// ---------------------------------------------------------
///
/// Find times at which point-triangle proximity is equal to the given collision epsilon
///
// ---------------------------------------------------------

void find_point_triangle_proximity_equals_epsilon_times(const Vec3d &x0, const Vec3d &x1, const Vec3d &x2, const Vec3d &x3,
                                                        const Vec3d &xnew0, const Vec3d &xnew1, const Vec3d &xnew2, const Vec3d &xnew3,
                                                        double collision_epsilon,
                                                        std::vector<double> &root_times, bool verbose )
{
   
   //
   // First use the cubic solver to find intervals
   //
   
   // cubic coefficients, A*t^3+B*t^2+C*t+D (for t in [0,1])
   Vec3d x03=x0-x3, x13=x1-x3, x23=x2-x3;
   Vec3d v03=(xnew0-xnew3)-x03, v13=(xnew1-xnew3)-x13, v23=(xnew2-xnew3)-x23;
   double A=triple(v03,v13,v23),
   B=triple(x03,v13,v23)+triple(v03,x13,v23)+triple(v03,v13,x23),
   C=triple(x03,x13,v23)+triple(x03,v13,x23)+triple(v03,x13,x23),
   D=triple(x03,x13,x23);   
   
   // If a possible root lies just outside [0,1], clamp it and check it.  This tol tells us how far outside [0,1] we will check.
   const double interval_tol = 1e-2;
   
   std::vector<double> interval_times;
   
   get_cubic_intervals( A, B, C, D, interval_tol, interval_times, verbose );
   
   //
   // We also need to get the roots of the cubic as intervals. The proximity function is always nonnegative, so can't detect
   // trajectories passing the plane of the triangle if the start and end proximities are both > eps.
   //
   
   std::vector<double> coplanarity_times;
   
   find_coplanarity_times( x0, x1, x2, x3, xnew0, xnew1, xnew2, xnew3,
                          coplanarity_times, verbose );
   
   for ( unsigned int i = 0; i <  coplanarity_times.size(); ++i )
   {
      add_unique( interval_times, coplanarity_times[i] );
   }
   
   sort( interval_times.begin(), interval_times.end() );
   
   //
   // Now use our general root solver to find points where f(x) = [proximity - eps] crosses zero.
   //
   
   PointTriangleProximityFunction func;
   func.p = x0;         func.t0 = x1;        func.t1 = x2;        func.t2 = x3;
   func.pnew = xnew0;   func.tnew0 = xnew1;  func.tnew1 = xnew2;  func.tnew2 = xnew3;
   func.epsilon = collision_epsilon;
   
   root_times.clear();
   
   const double interval_bdry_tol = 1e-14;
   const double zero_cross_tol = 1e-15;
   
   find_roots( &func, interval_times, interval_bdry_tol, zero_cross_tol, root_times, verbose );
   
}

double edge_edge_minimum_distance(const Vec3d &x0, const Vec3d &x1, const Vec3d &x2, const Vec3d &x3,
                                  const Vec3d &xnew0, const Vec3d &xnew1, const Vec3d &xnew2, const Vec3d &xnew3,
                                  double &min_t, bool verbose )
{
   //
   // First use the cubic solver to find intervals
   //
   
   // cubic coefficients, A*t^3+B*t^2+C*t+D (for t in [0,1])
   Vec3d x03=x0-x3, x13=x1-x3, x23=x2-x3;
   Vec3d v03=(xnew0-xnew3)-x03, v13=(xnew1-xnew3)-x13, v23=(xnew2-xnew3)-x23;
   double A=triple(v03,v13,v23),
   B=triple(x03,v13,v23)+triple(v03,x13,v23)+triple(v03,v13,x23),
   C=triple(x03,x13,v23)+triple(x03,v13,x23)+triple(v03,x13,x23),
   D=triple(x03,x13,x23);   
   
   // If a possible root lies just outside [0,1], clamp it and check it.  This tol tells us how far outside [0,1] we will check.
   const double interval_tol = 1e-2;
   
   std::vector<double> interval_times;
   
   if ( verbose ) { std::cout << " ----------- finding cubic intervals ----------- " << std::endl; }
   
   get_cubic_intervals( A, B, C, D, interval_tol, interval_times, verbose );
   
   //
   // We also need to get the roots of the cubic as intervals. The proximity function is always nonnegative, so can't detect
   // trajectories where the two edges pass through each other if they start and end with proximity > epsilon.
   //
   
   std::vector<double> coplanarity_times;
   
   if ( verbose ) { std::cout << " ----------- finding cubic roots ----------- " << std::endl; }
   
   find_coplanarity_times( x0, x1, x2, x3, xnew0, xnew1, xnew2, xnew3,
                          coplanarity_times, verbose );
   
   for ( unsigned int i = 0; i <  coplanarity_times.size(); ++i )
   {
      add_unique( interval_times, coplanarity_times[i] );
   }
   
   sort( interval_times.begin(), interval_times.end() );

   //
   // Now check distance at all times and return the min
   //
   
   double min_dist = 1e30;
   
   for ( unsigned int i = 0; i <  interval_times.size(); ++i )
   {
      double t = interval_times[i];
      Vec3d x0t = (1-t)*x0 + t*xnew0;
      Vec3d x1t = (1-t)*x1 + t*xnew1;
      Vec3d x2t = (1-t)*x2 + t*xnew2;
      Vec3d x3t = (1-t)*x3 + t*xnew3;
      double distance;
      check_edge_edge_proximity( x0t, x1t, x2t, x3t, distance );
      
      if ( distance < min_dist )
      {
         min_t = t;
         min_dist = distance;
      }

   }
   
   return min_dist;
   
}

double point_triangle_minimum_distance(const Vec3d &x0, const Vec3d &x1, const Vec3d &x2, const Vec3d &x3,
                                       const Vec3d &xnew0, const Vec3d &xnew1, const Vec3d &xnew2, const Vec3d &xnew3,
                                       double &min_t, bool verbose )
{
   //
   // First use the cubic solver to find intervals
   //
   
   // cubic coefficients, A*t^3+B*t^2+C*t+D (for t in [0,1])
   Vec3d x03=x0-x3, x13=x1-x3, x23=x2-x3;
   Vec3d v03=(xnew0-xnew3)-x03, v13=(xnew1-xnew3)-x13, v23=(xnew2-xnew3)-x23;
   double A=triple(v03,v13,v23),
   B=triple(x03,v13,v23)+triple(v03,x13,v23)+triple(v03,v13,x23),
   C=triple(x03,x13,v23)+triple(x03,v13,x23)+triple(v03,x13,x23),
   D=triple(x03,x13,x23);   
   
   // If a possible root lies just outside [0,1], clamp it and check it.  This tol tells us how far outside [0,1] we will check.
   const double interval_tol = 1e-2;
   
   std::vector<double> interval_times;
   
   get_cubic_intervals( A, B, C, D, interval_tol, interval_times, verbose );
   
   //
   // We also need to get the roots of the cubic as intervals. The proximity function is always nonnegative, so can't detect
   // trajectories passing the plane of the triangle if the start and end proximities are both > eps.
   //
   
   std::vector<double> coplanarity_times;
   
   find_coplanarity_times( x0, x1, x2, x3, xnew0, xnew1, xnew2, xnew3,
                          coplanarity_times, verbose );
   
   for ( unsigned int i = 0; i <  coplanarity_times.size(); ++i )
   {
      add_unique( interval_times, coplanarity_times[i] );
   }
   
   sort( interval_times.begin(), interval_times.end() );
   
   //
   // Now check distance at all times and return the min
   //
   
   double min_dist = 1e30;
   
   for ( unsigned int i = 0; i <  interval_times.size(); ++i )
   {
      double t = interval_times[i];
      Vec3d x0t = (1-t)*x0 + t*xnew0;
      Vec3d x1t = (1-t)*x1 + t*xnew1;
      Vec3d x2t = (1-t)*x2 + t*xnew2;
      Vec3d x3t = (1-t)*x3 + t*xnew3;
      double distance;
      check_point_triangle_proximity( x0t, x1t, x2t, x3t, distance );
      
      if ( distance < min_dist )
      {
         min_t = t;
         min_dist = distance;
      }
   }
   
   return min_dist;
   
}


// ---------------------------------------------------------
///
/// Continuous edge-edge collision detection
///
// ---------------------------------------------------------

bool check_edge_edge_collision(const Vec3d &x0, const Vec3d &x1, const Vec3d &x2, const Vec3d &x3,
                               const Vec3d &xnew0, const Vec3d &xnew1, const Vec3d &xnew2, const Vec3d &xnew3,
                               double collision_epsilon, bool verbose )
{
   std::vector<double> possible_times;
   
   find_edge_edge_proximity_equals_epsilon_times( x0, x1, x2, x3, 
                                                 xnew0, xnew1, xnew2, xnew3, 
                                                 collision_epsilon,
                                                 possible_times,
                                                 verbose );
   
   for(unsigned int a=0; a<possible_times.size(); ++a)
   {
      double t=possible_times[a];
      Vec3d xt0=(1-t)*x0+t*xnew0, xt1=(1-t)*x1+t*xnew1, xt2=(1-t)*x2+t*xnew2, xt3=(1-t)*x3+t*xnew3;
      double distance;
      check_edge_edge_proximity(xt0, xt1, xt2, xt3, distance);
      //assert( distance <= collision_epsilon );
      return true;
   }
   
   return false;
}

// ---------------------------------------------------------
///
/// Continuous edge-edge collision detection with collision normal, barycentric coordinates and time of collision.
///
// ---------------------------------------------------------

bool check_edge_edge_collision(const Vec3d &x0, const Vec3d &x1, const Vec3d &x2, const Vec3d &x3,
                               const Vec3d &xnew0, const Vec3d &xnew1, const Vec3d &xnew2, const Vec3d &xnew3,
                               double &s0, double &s2, Vec3d &normal, double &t, double collision_epsilon, bool verbose)
{
   
   std::vector<double> possible_times;
   
   find_edge_edge_proximity_equals_epsilon_times( x0, x1, x2, x3, 
                                                  xnew0, xnew1, xnew2, xnew3, 
                                                  collision_epsilon,
                                                  possible_times,
                                                  verbose );
   
   static const double dt = 1.0;   //0.05;
   const Vec3d v0 = (xnew0 - x0) / dt;
   const Vec3d v1 = (xnew1 - x1) / dt;
   const Vec3d v2 = (xnew2 - x2) / dt;
   const Vec3d v3 = (xnew3 - x3) / dt;
   
   for(unsigned int a=0; a<possible_times.size(); ++a)
   {
      
      t=possible_times[a];
           
      Vec3d xt0=(1-t)*x0+t*xnew0, xt1=(1-t)*x1+t*xnew1, xt2=(1-t)*x2+t*xnew2, xt3=(1-t)*x3+t*xnew3;
      double distance;
      check_edge_edge_proximity( xt0, xt1, xt2, xt3, distance, s0, s2, normal);
      
      //assert( distance <= collision_epsilon );
      
      assert( t > 0.0 );
      
      bool used_collision_normal = false;
      
      if(distance < 1e-2*collision_epsilon )
      { 
         // if we don't trust the normal...
         // first try the cross-product of edges at collision time
         normal=cross(xt1-xt0, xt3-xt2);
         double m=mag(normal);
         if(m>sqr(collision_epsilon))
         {
            if ( verbose )
            {
               std::cout << "cross product normal: " << normal/m << std::endl;
            }
            normal/=m;
         }
         else
         {
            // if that didn't work, try cross-product of edges at the start
            normal=cross(x1-x0, x3-x2);
            m=mag(normal);
            if(m>sqr(collision_epsilon))
            {
               std::cout << "taking cross product of start edges normal" << std::endl;
               normal/=m;
            }
            else
            {
               // if that didn't work, try vector between points at the start
               normal=(s2*x2+(1-s2)*x3)-(s0*x0+(1-s0)*x1);
               m=mag(normal);
               if(m>collision_epsilon)
               {
                  std::cout << "taking vector between points normal" << std::endl;
                  normal/=m;
               }
               else
               {
                  // if that didn't work, boy are we in trouble; just get any non-parallel vector
                  Vec3d dx=xt1-xt0;
                  if(dx[0]!=0 || dx[1]!=0)
                  {
                     std::cout << "normal a" << std::endl;
                     normal=Vec3d(dx[1], -dx[0], 0);
                     normal/=mag(normal);
                  }
                  else
                  {
                     dx=xt3-xt2;
                     if(dx[0]!=0 || dx[1]!=0)
                     {
                        std::cout << "normal b" << std::endl;                           
                        normal=Vec3d(dx[1], -dx[0], 0);
                        normal/=mag(normal);
                     }
                     else
                     {
                        std::cout << "normal last resort" << std::endl;                           
                        normal=Vec3d(0, 1, 0); // the last resort
                     }
                  }
               }
            }
         }
      }
      else
      {
         used_collision_normal = true;
         if ( verbose ) std::cout << "trusting the collision normal " << std::endl;
      }
       

//      double relvel = dot( normal, s0*v0 + (1.0-s0)*v1 - (s2*v2 + (1.0-s2)*v3) );     
//      if( relvel > 0.0 )
//      {
//
//
//         std::cout << "----------------" << std::endl;
//         std::cout << "relvel: " << relvel << "\tused_collision_normal: " << used_collision_normal << std::endl;
//         find_edge_edge_proximity_equals_epsilon_times( x0, x1, x2, x3, 
//                                                        xnew0, xnew1, xnew2, xnew3, 
//                                                        collision_epsilon,
//                                                        possible_times,
//                                                        true );         
//      }
      
      return true;
      
   }
   
   return false;
   
}

// ---------------------------------------------------------
///
/// Continuous point-triangle collision detection
///
// ---------------------------------------------------------

bool check_point_triangle_collision(const Vec3d &x0, const Vec3d &x1, const Vec3d &x2, const Vec3d &x3,
                                    const Vec3d &xnew0, const Vec3d &xnew1, const Vec3d &xnew2, const Vec3d &xnew3,
                                    double collision_epsilon, bool verbose )
{
   std::vector<double> possible_times;

   find_point_triangle_proximity_equals_epsilon_times( x0, x1, x2, x3, 
                                                      xnew0, xnew1, xnew2, xnew3, 
                                                      collision_epsilon,
                                                      possible_times, verbose );
   
   for(unsigned int a=0; a<possible_times.size(); ++a)
   {
      double t=possible_times[a];
      Vec3d xt0=(1-t)*x0+t*xnew0, xt1=(1-t)*x1+t*xnew1, xt2=(1-t)*x2+t*xnew2, xt3=(1-t)*x3+t*xnew3;
      double distance;
      check_point_triangle_proximity(xt0, xt1, xt2, xt3, distance);
      //assert( distance <= collision_epsilon );
      return true;
   }
   return false;
}

// ---------------------------------------------------------
///
/// Continuous point-triangle collision detection with collision normal, barycentric coordinates and time of collision.
///
// ---------------------------------------------------------

bool check_point_triangle_collision(const Vec3d &x0, const Vec3d &x1, const Vec3d &x2, const Vec3d &x3,
                                    const Vec3d &xnew0, const Vec3d &xnew1, const Vec3d &xnew2, const Vec3d &xnew3,
                                    double &s1, double &s2, double &s3, Vec3d &normal, double &t, double collision_epsilon,
                                    bool verbose )
{
   std::vector<double> possible_times;
      
   find_point_triangle_proximity_equals_epsilon_times( x0, x1, x2, x3, 
                                                       xnew0, xnew1, xnew2, xnew3, 
                                                       collision_epsilon,
                                                       possible_times,
                                                       verbose );

   static const double dt = 1.0;   //0.05;
   const Vec3d v0 = (xnew0 - x0) / dt;
   const Vec3d v1 = (xnew1 - x1) / dt;
   const Vec3d v2 = (xnew2 - x2) / dt;
   const Vec3d v3 = (xnew3 - x3) / dt;
   
   for(unsigned int a=0; a<possible_times.size(); ++a)
   {
      t=possible_times[a];
                  
      Vec3d xt0=(1-t)*x0+t*xnew0, xt1=(1-t)*x1+t*xnew1, xt2=(1-t)*x2+t*xnew2, xt3=(1-t)*x3+t*xnew3;
      double distance;
      check_point_triangle_proximity(xt0, xt1, xt2, xt3, distance, s1, s2, s3, normal);
      
      //assert( distance <= collision_epsilon );
      
      assert( t > 0.0 );

      bool used_collision_normal = false;
      
      // now figure out a decent normal
      if(distance< 1e-2*collision_epsilon)  // if we don't trust the normal...
      {
         // first try the triangle normal at collision time
         normal=cross(xt2-xt1, xt3-xt1);
         double m=mag(normal);
         if(m>sqr(collision_epsilon))
         {
            if ( verbose ) { std::cout << "triangle normal" << std::endl; }
            normal/=m;
         }else
         {
            // if that didn't work, try triangle normal at start
            normal=cross(x2-x1, x3-x1);
            m=mag(normal);
            if(m>sqr(collision_epsilon))
            {
               if ( verbose ) { std::cout << "triangle normal at start" << std::endl; }
               normal/=m;
            }
            else
            {
               // if that didn't work, try vector between points at the start
               normal=(s1*x1+s2*x2+s3*x3)-x0;
               m=mag(normal);
               if(m>collision_epsilon)
               {
                  if ( verbose ) { std::cout << "between points at start" << std::endl; }
                  normal/=m;
               }else{
                  // if that didn't work, boy are we in trouble; just get any non-parallel vector
                  Vec3d dx=xt2-xt1;
                  if(dx[0]!=0 || dx[1]!=0){
                     normal=Vec3d(dx[1], -dx[0], 0);
                     normal/=mag(normal);
                  }else{
                     dx=xt3-xt1;
                     if(dx[0]!=0 || dx[1]!=0){
                        normal=Vec3d(dx[1], -dx[0], 0);
                        normal/=mag(normal);
                     }else{
                        normal=Vec3d(0, 1, 0); // the last resort
                     }
                  }
               }
            }
         }
      }
      else
      {
         if ( verbose ) std::cout << "trusting the collision normal " << std::endl;
         used_collision_normal = true;
      }
      
//      double relvel = dot( normal, v0 - ( s1*v1 + s2*v2 + s3*v3 ) );
//      
//      if( relvel > 0.0 )
//      {
//         std::cout << "relvel: " << relvel << "\tused_collision_normal: " << used_collision_normal << std::endl;
//         
//         find_point_triangle_proximity_equals_epsilon_times( x0, x1, x2, x3, 
//                                                            xnew0, xnew1, xnew2, xnew3, 
//                                                            collision_epsilon,
//                                                            possible_times,
//                                                            true );         
//      }
      
      return true;
      
   }
   
   return false;
         
}



// ---------------------------------------------------------
///
/// Detect if point p lies within the tetrahedron defined by x1 x2 x3 x4.
/// Assumes tet is given with x123 forming an oriented triangle.
/// Returns true if vertex proximity to any of the tet's faces is less than epsilon.
///
// ---------------------------------------------------------

bool vertex_is_in_tetrahedron( const Vec3d &p, const Vec3d &x1, const Vec3d &x2, const Vec3d &x3, const Vec3d &x4, double epsilon )
{
   double distance;  
   
   // triangle 1 - x1 x2 x3
   double a = signed_volume(p, x1, x2, x3);
   
   if (fabs(a) < epsilon)     // degenerate
   {        
      check_point_triangle_proximity(p, x1, x2, x3, distance);
      if ( distance < epsilon )
      {
         return true;
      }
   }
   
   // triangle 2 - x2 x4 x3
   double b = signed_volume(p, x2, x4, x3);
   
   if (fabs(b) < epsilon)         // degenerate
   {
      check_point_triangle_proximity(p, x2, x4, x3, distance);
      if ( distance < epsilon )
      {
         return true;
      }
   }
   
   if ((a > epsilon) ^ (b > epsilon))
   {
      return false;
   }
   
   // triangle 3 - x1 x4 x2
   double c = signed_volume(p, x1, x4, x2);
   if (fabs(c) < epsilon) 
   {
      check_point_triangle_proximity(p, x1, x4, x2, distance);
      if ( distance < epsilon )
      {
         return true;
      }
   }
   
   if ((a > epsilon) ^ (c > epsilon))
   {
      return false;
   }
   
   // triangle 4 - x1 x3 x4
   double d = signed_volume(p, x1, x3, x4);
   if (fabs(d) < epsilon) 
   { 
      check_point_triangle_proximity(p, x1, x3, x4, distance);
      if ( distance < epsilon )
      {
         return true;
      }
   }
   
   if ((a > epsilon) ^ (d > epsilon))
   {
      return false;
   }
   
   // if there was a degenerate case, but the point was not in any triangle, the point must be outside the tet
   if ( (fabs(a) < epsilon) || (fabs(b) < epsilon) || (fabs(c) < epsilon) || (fabs(d) < epsilon) ) 
   {
      return false;
   }
   
   return true;    // point is on the same side of all triangles
}

