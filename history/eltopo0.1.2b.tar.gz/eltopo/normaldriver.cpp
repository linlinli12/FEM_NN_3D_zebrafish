// ---------------------------------------------------------
//
//  normaldriver.cpp
//
//  Mesh driver for motion in the normal direction using vertex 
//  normals (area-weighted average of incident triangle normals).
//
// ---------------------------------------------------------

// ---------------------------------------------------------
// Includes
// ---------------------------------------------------------

#include <normaldriver.h>

#include <dynamicsurface.h>
#include <faceoff.h>
#include <nondestructivetrimesh.h>
#include <geometryinit.h>

// ---------------------------------------------------------
// Global externs
// ---------------------------------------------------------

// ---------------------------------------------------------
// Local constants, typedefs, macros
// ---------------------------------------------------------

// ---------------------------------------------------------
// Static function definitions
// ---------------------------------------------------------

// ---------------------------------------------------------
// Member function definitions
// ---------------------------------------------------------

// ---------------------------------------------------------
///
/// Assign the normal at each vertex as the vertex's velocity
///
// ---------------------------------------------------------

void NormalDriver::set_surface_velocity( const DynamicSurface& surf, std::vector<Vec3d>& out_velocity, double current_t, double& adaptive_dt )
{
   std::vector<Vec3d> displacements( surf.m_positions.size(), Vec3d(0,0,0) );
   out_velocity.resize( surf.m_positions.size(), Vec3d(0,0,0) );
   
   for ( unsigned int i = 0; i < surf.m_positions.size(); ++i )
   {
      if ( surf.m_mesh.vtxtri[i].size() == 0 ) 
      { 
         out_velocity[i] = Vec3d(0,0,0);
         continue;
      }
      
      Vec3d normal(0,0,0);
      double sum_areas = 0.0;
      for ( unsigned int j = 0; j < surf.m_mesh.vtxtri[i].size(); ++j )
      {
         double area = surf.get_triangle_area( surf.m_mesh.vtxtri[i][j] );
         normal += surf.get_triangle_normal( surf.m_mesh.vtxtri[i][j] ) * area;
         sum_areas += area;
      }
      //normal /= sum_areas;
      normal /= mag(normal);
      
      double switch_speed = (current_t >= 1.0) ? -speed : speed;
      out_velocity[i] = switch_speed * normal;
      
      displacements[i] = adaptive_dt * out_velocity[i];
   }
   
   double capped_dt = FaceOffDriver::compute_max_timestep_quadratic_solve( surf.m_mesh.tris, surf.m_positions, displacements, false );
   
   adaptive_dt = min( adaptive_dt, capped_dt );
}

// ---------------------------------------------------------
///
/// Compute the L1 error between the current mesh state and the analytical final state
///
// ---------------------------------------------------------

void NormalDriver::compute_l1_error( const DynamicSurface& surf )
{
      
   double total_error = 0.0;
   double total_area = 0.0;
   
   for ( unsigned int i = 0; i < surf.m_positions.size(); ++i )
   {
      if ( surf.m_mesh.vtxtri[i].size() == 0 )
      {
         // ignore deleted vertices
         continue;
      }
      
      double dist = fabs( signed_distance_entropy( surf.m_positions[i], sphere_a_centre, sphere_b_centre, max_radius, interior_radius ) );
      
      double area = 0;
      for ( unsigned int j = 0; j < surf.m_mesh.vtxtri[i].size(); ++j )
      {
         area += surf.get_triangle_area( surf.m_mesh.vtxtri[i][j] );
      }
      area /= 3;
      
      total_error += dist * area;
      total_area += area;
   }
   
   total_error /= total_area;
   
   std::cout << "L_1 error: " << total_error << std::endl;
}


// ---------------------------------------------------------
///
/// Compute the L_inf error between the current mesh state and the analytical final state
///
// ---------------------------------------------------------

void NormalDriver::compute_inf_error( const DynamicSurface& surf )
{
   
   double max_error = -1.0;
   
   for ( unsigned int i = 0; i < surf.m_positions.size(); ++i )
   {
      if ( surf.m_mesh.vtxtri[i].size() == 0 )
      {
         // ignore deleted vertices
         continue;
      }
      
      double dist = signed_distance_entropy( surf.m_positions[i], sphere_a_centre, sphere_b_centre, max_radius, interior_radius );
      max_error = max( max_error, fabs(dist) );
   }
   
   std::cout << "L_inf error: " << max_error << std::endl;
   
}


// ---------------------------------------------------------
///
/// Compute and output L1 and L_inf error measures
///
// ---------------------------------------------------------

void NormalDriver::compute_error( const DynamicSurface& surf, double current_t )
{
   std::cout << "Error at t = " << current_t << ": " << std::endl;
   compute_inf_error( surf );
   compute_l1_error( surf );
}




