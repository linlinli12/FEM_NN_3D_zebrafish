// ---------------------------------------------------------
//
//  parser.cpp
//
//  Parses a text file specifying the simulation parameters and initial conditions.
//
// ---------------------------------------------------------

// ---------------------------------------------------------
// Includes
// ---------------------------------------------------------

#include <parser.h>

#include <meshdriver.h>
#include <faceoff.h>
#include <meancurvature.h>
#include <normaldriver.h>
#include <sisccurlnoisedriver.h>
#include <enrightdriver.h>

#include <simulation.h>
#include <geometryinit.h>

#include <subdivisionscheme.h>

#include <meshloader.h>
#include <iomesh.h>

#include <marching_tiles_hires.h>

// ---------------------------------------------------------
// Static/non-member function definitions
// ---------------------------------------------------------


// ---------------------------------------------------------
///
/// Parse three double values, storing them in output vec
///
// ---------------------------------------------------------

void parse_vec3d( const std::string& line, std::string::size_type& loc, Vec3d& vec )
{
   std::string::size_type space_loc = line.find( " ", loc );
   std::string sub = line.substr( loc, space_loc-loc );
   
   double x = atof( sub.c_str() );
   
   loc = space_loc + 1;
   space_loc = line.find( " ", loc );
   sub = line.substr( loc, space_loc-loc );
   
   double y = atof( sub.c_str() );
   
   loc = space_loc + 1;
   space_loc = line.find( " ", loc );
   sub = line.substr( loc, space_loc-loc );
   
   double z = atof( sub.c_str() );
   
   loc = space_loc + 1;
   
   vec = Vec3d(x, y, z);
}


// ---------------------------------------------------------
///
/// Parse the line specifying the MeshDriver
///
// ---------------------------------------------------------

void parse_driver( const std::string& line, MeshDriver*& driver )
{
   std::string::size_type loc;
   
   loc = line.find( "faceoff", 0 );
   if ( loc != std::string::npos )
   {
      // get faceoff speed
      loc += strlen( "faceoff" ) + 1;
      std::string sub = line.substr( loc );
      double speed = atof( sub.c_str() );
      
      driver = new FaceOffDriver( speed, Vec3d( -0.25, 0.0, 0.0 ), Vec3d( 0.25, 0.0, 0.0 ), 0.4, 0.2 );
      
      return;
   }

   loc = line.find( "normaldriver", 0 );
   if ( loc != std::string::npos )
   {
      // get normal speed
      loc += strlen( "normaldriver" ) + 1;
      std::string sub = line.substr( loc );
      double speed = atof( sub.c_str() );
      
      driver = new NormalDriver( speed, Vec3d( -0.25, 0.0, 0.0 ), Vec3d( 0.25, 0.0, 0.0 ), 0.4, 0.2 );
      
      return;
   }
   
   loc = line.find( "meancurvature", 0 );
   if ( loc != std::string::npos )
   {
      // get meancurvature speed
      loc += strlen( "meancurvature" ) + 1;
      
      std::string::size_type space_loc = line.find( " ", loc );
      std::string sub = line.substr( loc, space_loc-loc );

      double speed = atof( sub.c_str() );
      
      assert( speed != 0.0 );
     
      std::cout << "meancurvature multiplier: " << speed << std::endl;
      
      loc = space_loc + 1;
      space_loc = line.find( " ", loc );
      std::string sub_filename = line.substr( loc, (space_loc - loc) );
     
      std::cout << "ground truth file: " << sub_filename << std::endl;
      
      Array3d sethian_final;
      read_signed_distance( sub_filename.c_str(), sethian_final );       

      loc = space_loc+1;
      
      Vec3d phi_domain_low;
      parse_vec3d( line, loc, phi_domain_low );

      std::cout << "ground truth domain low: " << phi_domain_low << std::endl;
      
      ++loc;
      
      space_loc = line.find( " ", loc );
      sub = line.substr( loc, space_loc-loc );
      
      double phi_domain_dx = atof( sub.c_str() );

      std::cout << "ground truth domain dx: " << phi_domain_dx << std::endl;
      
      driver = new MeanCurvatureDriver( speed, sethian_final, phi_domain_low, phi_domain_dx );
      
      return;
   }

   loc = line.find( "sisccurlnoise", 0 );
   if ( loc != std::string::npos )
   {
      std::cout << "initing curlnoise driver with SISC settings" << std::endl;
      driver = new SISCCurlNoiseDriver( );
      return;
   }
     
   loc = line.find( "enright", 0 );
   if ( loc != std::string::npos )
   {
      std::cout << "initing enright driver" << std::endl;
      driver = new EnrightDriver( );
      return;
   }

   
}

// ---------------------------------------------------------
///
/// Parse the line initializing the Simulation object
///
// ---------------------------------------------------------

void parse_simulation( const std::string& line, Simulation*& sim )
{
   std::string::size_type loc;   
   loc = line.find( "simulation", 0 );
   
   assert( loc != std::string::npos );

   loc += strlen( "simulation" ) + 1;
      
   std::string::size_type space_loc = line.find( " ", loc );
   
   assert( space_loc != std::string::npos );
   
   std::string sub = line.substr( loc, space_loc );
   double dt = atof( sub.c_str() );
   assert( dt != 0.0 );
   
   ++space_loc;
   
   sub = line.substr( space_loc );
   double maxt = atof( sub.c_str() );
   assert( maxt != 0.0 );

   std::cout << "initing sim " << dt << " " << maxt << std::endl;
   sim = new Simulation( dt, maxt );
     
}

// ---------------------------------------------------------
///
/// Parse the line specifying the type of subdivision to use
///
// ---------------------------------------------------------

void parse_subdivision_scheme( const std::string& line, SurfTrackInitializationParameters& init )
{
   std::string::size_type loc = line.find( "butterfly", 0 );
   if ( loc != std::string::npos )
   {
      std::cout << "initing butterfly subdivision" << std::endl;
      init.subdivision_scheme = new ButterflyScheme( );
      return;
   }

   loc = line.find( "midpoint", 0 );
   if ( loc != std::string::npos )
   {
      std::cout << "initializing mid-point subdivision" << std::endl;
      init.subdivision_scheme = new MidpointScheme( );
      return;
   }
   
   
}

// ---------------------------------------------------------
///
/// Use MarchingTilesHiRes to create a triangle mesh from a signed distance field
///
// ---------------------------------------------------------

void contour_phi( const Vec3d& domain_low, double domain_dx, Array3d& phi, std::vector<Vec3ui>& tris, std::vector<Vec3d>& verts )
{
   MarchingTilesHiRes tiles( domain_low, domain_dx, phi );
   
   std::cout << "Contouring..." << std::endl;
   
   tiles.contour();
   tiles.improve_mesh();
   
   for ( unsigned int i = 0; i < tiles.tri.size(); ++i )
   {
      tris.push_back( tiles.tri[i] );
   }
   
   for ( unsigned int i = 0; i < tiles.x.size(); ++i )
   {
      verts.push_back( tiles.x[i] );
   }   
   
}

void append_mesh( std::vector<Vec3ui>& tris, 
                 std::vector<Vec3d>& verts,
                 std::vector<Vec3d>& velocities,
                 std::vector<double>& masses,
                 std::vector<Vec3ui>& new_tris, 
                 std::vector<Vec3d>& new_verts,
                 std::vector<Vec3d>& new_velocities,
                 std::vector<double>& new_masses )
{
   unsigned int old_num_verts = verts.size();
   
   for ( unsigned int i = 0; i < new_verts.size(); ++i )
   {
      verts.push_back( new_verts[i] );
   }

   for ( unsigned int i = 0; i < new_tris.size(); ++i )
   {
      tris.push_back( new_tris[i] + Vec3ui(old_num_verts) );
   }

   for ( unsigned int i = 0; i < new_masses.size(); ++i )
   {
      masses.push_back( new_masses[i] );
   }

   for ( unsigned int i = 0; i < new_velocities.size(); ++i )
   {
      velocities.push_back( new_velocities[i] );
   }
   
}
                 
extern bool g_skip_to_impact_zones;

// ---------------------------------------------------------
///
/// Determine command type and run appropriate subroutine
///
// ---------------------------------------------------------

void parse_command( const std::string& line,                   
                    MeshDriver*& driver, 
                    Simulation*& sim, 
                    std::vector<Vec3ui>& tris, 
                    std::vector<Vec3d>& verts,
                    std::vector<Vec3d>& velocities,
                    std::vector<double>& masses,
                    SurfTrackInitializationParameters& init )

{
   static bool sim_initialized = false;
   
   //
   // MeshDriver
   //
   
   std::string::size_type loc = line.find( "driver", 0 );
   if ( loc != std::string::npos )
   {
      parse_driver( line, driver );
      return;
   }
   
   //
   // Simulation
   //
   loc = line.find( "simulation", 0 );
   if ( loc != std::string::npos )
   {
      parse_simulation( line, sim );
      sim_initialized = true;
      return;
   }

   loc = line.find( "setframe", 0 );
   if ( loc != std::string::npos )
   {
      if ( !sim_initialized )
      {
         std::cout << "SCRIPT ERROR: sim not initialized" << std::endl;
      }
      
      loc += strlen( "setframe" ) + 1;
      std::string sub = line.substr( loc );
      int i = atoi( sub.c_str() );
      sim->curr_frame = i;
      std::cout << "curr_frame: " << sim->curr_frame << ", curr_t = " << sim->curr_t << std::endl;
      return;
   }

   //
   // SurfTrackInitializationParameters
   //
   
   loc = line.find( "use_fraction", 0 );
   if ( loc != std::string::npos )
   {
      loc += strlen( "use_fraction" ) + 1;
      std::string sub = line.substr( loc );
      int i = atoi( sub.c_str() );
      init.use_fraction = i;
      return;
   }

   loc = line.find( "min_edge_length", 0 );
   if ( loc != std::string::npos )
   {
      loc += strlen( "min_edge_length" ) + 1;
      std::string sub = line.substr( loc );
      double d = atof( sub.c_str() );
      init.min_edge_length = d;
      return;
   }

   loc = line.find( "max_edge_length", 0 );
   if ( loc != std::string::npos )
   {
      loc += strlen( "max_edge_length" ) + 1;
      std::string sub = line.substr( loc );
      double d = atof( sub.c_str() );
      init.max_edge_length = d;
      return;
   }

   loc = line.find( "max_volume_change", 0 );
   if ( loc != std::string::npos )
   {
      loc += strlen( "max_volume_change" ) + 1;
      std::string sub = line.substr( loc );
      double d = atof( sub.c_str() );
      init.max_volume_change = d;
      return;
   }

   loc = line.find( "subdivision", 0 );
   if ( loc != std::string::npos )
   {
      parse_subdivision_scheme( line, init );
      return;
   }
   
   //
   // Options
   //

   loc = line.find( "allow_topology_changes", 0 );
   if ( loc != std::string::npos )
   {
      loc += strlen( "allow_topology_changes" ) + 1;
      std::string sub = line.substr( loc );
      int i = atoi( sub.c_str() );
      init.allow_topology_changes = i;
      
      std::cout << "allow_topology_changes: " << init.allow_topology_changes << std::endl;
      
      return;
   }

   loc = line.find( "collision_safety", 0 );
   if ( loc != std::string::npos )
   {
      loc += strlen( "collision_safety" ) + 1;
      std::string sub = line.substr( loc );
      int i = atoi( sub.c_str() );
      init.collision_safety = i;
      return;
   }

   loc = line.find( "perform_improvement", 0 );
   if ( loc != std::string::npos )
   {
      loc += strlen( "perform_improvement" ) + 1;
      std::string sub = line.substr( loc );
      int i = atoi( sub.c_str() );
      init.perform_improvement = i;
      return;
   }
   
   //
   // Geometry
   //
   
   loc = line.find( "loadfile", 0 );
   if ( loc != std::string::npos )
   {
      loc += strlen( "loadfile" ) + 1;
      std::string filename = line.substr( loc ); 

      std::vector<Vec3ui> new_tris;                  
      std::vector<Vec3d> new_verts;            
      
      MeshLoader loader( filename );    
      loader.get_triangles(tris);
      loader.get_vertices(verts);      

      std::vector<double> new_masses( verts.size(), 1.0 );
      std::vector<Vec3d> new_velocities( verts.size(), Vec3d(0.0) );

      append_mesh( tris, verts, velocities, masses, new_tris, new_verts, new_velocities, new_masses );
   }

   loc = line.find( "loadbinaryfilewithvelocities", 0 );
   if ( loc != std::string::npos )
   {
      loc += strlen( "loadbinaryfilewithvelocities" ) + 1;
      std::string filename = line.substr( loc ); 

      NonDestructiveTriMesh temp_mesh;
      std::vector<Vec3d> new_verts;            
      std::vector<double> new_masses;
      std::vector<Vec3d> new_velocities;      
      double t;      
      read_binary_file_with_velocities( temp_mesh, new_verts, new_masses, new_velocities, t, filename.c_str() );      
      
      std::vector<Vec3ui> new_tris = temp_mesh.tris;
      append_mesh( tris, verts, velocities, masses, new_tris, new_verts, new_velocities, new_masses );

      if ( sim_initialized )
      {
         sim->curr_t = t;
      }
            
      //g_skip_to_impact_zones = true;
      
      return;
   }
   
   loc = line.find( "loadbinaryfile", 0 );
   if ( loc != std::string::npos )
   {
      loc += strlen( "loadbinaryfile" ) + 1;
      std::string filename = line.substr( loc ); 

      NonDestructiveTriMesh temp_mesh;
      std::vector<Vec3d> new_verts;      
      std::vector<double> new_masses;
      double t;
      read_binary_file( temp_mesh, new_verts, new_masses, t, filename.c_str() );      

      std::vector<Vec3ui> new_tris = temp_mesh.tris;
      std::vector<Vec3d> new_velocities( new_verts.size(), Vec3d(0,0,0) );
      append_mesh( tris, verts, velocities, masses, new_tris, new_verts, new_velocities, new_masses );
      
      if ( sim_initialized )
      {
         sim->curr_t = t;
      }
      
      return;
   }   
   
   static Vec3d domain_low;
   static Vec3d domain_high;
   static double domain_dx;
   
   loc = line.find( "domain_low", 0 );
   if ( loc != std::string::npos )
   {
      loc += strlen( "domain_low" ) + 1;
      parse_vec3d( line, loc, domain_low );
      return;
   }

   loc = line.find( "domain_high", 0 );
   if ( loc != std::string::npos )
   {
      loc += strlen( "domain_high" ) + 1;
      parse_vec3d( line, loc, domain_high );
      return;
   }

   loc = line.find( "domain_dx", 0 );
   if ( loc != std::string::npos )
   {
      loc += strlen( "domain_dx" ) + 1;
      std::string sub = line.substr( loc );
      double d = atof( sub.c_str() );
      domain_dx = d;
      return;
   }

   loc = line.find( "loadphi", 0 );
   if ( loc != std::string::npos )
   {
      loc += strlen( "loadphi" ) + 1;
      std::string filename = line.substr( loc ); 
      
      Array3d phi;
      read_signed_distance( filename.c_str(), phi );

      std::vector<Vec3ui> new_tris;
      std::vector<Vec3d> new_verts;
      contour_phi( domain_low, domain_dx, phi, new_tris, new_verts );
      std::vector<Vec3d> new_velocities( new_verts.size(), Vec3d(0,0,0) );
      std::vector<double> new_masses( new_verts.size(), 0 );
      
      append_mesh( tris, verts, velocities, masses, new_tris, new_verts, new_velocities, new_masses );
      
      return;
   }
   
   loc = line.find( "create_sphere", 0 );
   if ( loc != std::string::npos )
   {
      Vec3d centre;
      double radius;

      loc += strlen( "create_sphere" ) + 1;
      
      parse_vec3d( line, loc, centre );
      
      std::string sub = line.substr( loc );      
      double d = atof( sub.c_str() );
      radius = d;
      
      Array3d phi;
      
      create_sphere_signed_distance( centre, radius, domain_dx, domain_low, domain_high, phi );
      
      std::vector<Vec3ui> new_tris;
      std::vector<Vec3d> new_verts;
      contour_phi( domain_low, domain_dx, phi, new_tris, new_verts );
      
      //
      // run a few iterations of improvement to get a nice initial mesh
      //
      
      std::vector<double> new_masses( new_verts.size(), 1.0 );
      SurfTrack* temp_surf = new SurfTrack( new_verts, new_tris, new_masses, init );   
      
      project_to_exact_sphere( temp_surf->m_positions, centre, radius );
      
      for ( unsigned int i = 0; i < 5; ++i )
      {
         temp_surf->improve_mesh();
         
         temp_surf->m_mesh.nondestructive_clear_unused();  
         temp_surf->m_mesh.update_connectivity( temp_surf->m_positions.size() );
         
         temp_surf->clear_deleted_vertices();
         
         temp_surf->m_mesh.update_connectivity( temp_surf->m_positions.size() );
         temp_surf->rebuild_static_broad_phase();
      }
      
      project_to_exact_sphere( temp_surf->m_positions, centre, radius );
      
      new_tris = temp_surf->m_mesh.tris;
      new_verts = temp_surf->m_positions;
      new_masses = temp_surf->m_masses;
      std::vector<Vec3d> new_velocities = temp_surf->m_velocities;
      
      append_mesh( tris, verts, velocities, masses, new_tris, new_verts, new_velocities, new_masses );
      
      delete temp_surf;
      
      return;
   }
   
   loc = line.find( "create_two_spheres", 0 );
   if ( loc != std::string::npos )
   {
      Vec3d centre_a, centre_b;
      double radius;
      
      loc += strlen( "create_two_spheres" ) + 1;
      
      parse_vec3d( line, loc, centre_a );     
      ++loc;
      parse_vec3d( line, loc, centre_b );
      ++loc;
      
      std::string sub = line.substr( loc );
      double d = atof( sub.c_str() );
      radius = d;
      
      Array3d phi;
      
      create_two_sphere_signed_distance( centre_a, centre_b, radius, domain_dx, domain_low, domain_high, phi );      
      
      std::vector<Vec3ui> new_tris;
      std::vector<Vec3d> new_verts;
      
      contour_phi( domain_low, domain_dx, phi, new_tris, new_verts );
      
      //
      // run a few iterations of improvement to get a nice initial mesh
      //
      
      double real_gamma = init.max_volume_change;
      
      init.max_volume_change = 0.1;
      
      std::vector<double> new_masses( new_verts.size(), 1.0 );
      SurfTrack* temp_surf = new SurfTrack( new_verts, new_tris, new_masses, init );   
      
      project_to_exact_2_spheres( temp_surf, centre_a, centre_b, radius, 0.0 );
      
      for ( unsigned int i = 0; i < 5; ++i )
      {
         temp_surf->improve_mesh();
         
         temp_surf->m_mesh.nondestructive_clear_unused();  
         temp_surf->m_mesh.update_connectivity( temp_surf->m_positions.size() );
         
         temp_surf->clear_deleted_vertices();
         
         temp_surf->m_mesh.update_connectivity( temp_surf->m_positions.size() );
         temp_surf->rebuild_static_broad_phase();
      }
      
      project_to_exact_2_spheres( temp_surf, centre_a, centre_b, radius, 0.0 );
      
      new_tris = temp_surf->m_mesh.tris;
      new_verts = temp_surf->m_positions;
      new_masses = temp_surf->m_masses;
      std::vector<Vec3d> new_velocities( new_verts.size(), Vec3d(0,0,0) );
      
      append_mesh( tris, verts, velocities, masses, new_tris, new_verts, new_velocities, new_masses );
      
      delete temp_surf;
      
      init.max_volume_change = real_gamma;
      
      return;
   }

   loc = line.find( "create_dumbbell", 0 );
   if ( loc != std::string::npos )
   {
      loc += strlen( "create_dumbbell" ) + 1;
      
      Vec3d centre_a, centre_b;
            
      parse_vec3d( line, loc, centre_a );     
      ++loc;
      parse_vec3d( line, loc, centre_b );
      ++loc;
      
      std::string::size_type space_loc = line.find( " ", loc );
      std::string sub = line.substr( loc, space_loc-loc );
      
      double radius = atof( sub.c_str() );
      
      loc = space_loc + 1;
      sub = line.substr( loc );
      
      double handle_width = atof( sub.c_str() );
      
      Array3d phi;
      
      create_dumbbell_signed_distance( centre_a, centre_b, radius, handle_width, domain_dx, domain_low, domain_high, phi );      
      
      std::vector<Vec3ui> new_tris;
      std::vector<Vec3d> new_verts;

      contour_phi( domain_low, domain_dx, phi, new_tris, new_verts );
      
      project_to_exact_dumbbell( new_verts, centre_a, centre_b, radius, handle_width );

      std::vector<double> new_masses( new_verts.size(), 1.0 );
      std::vector<Vec3d> new_velocities( new_verts.size(), Vec3d(0,0,0) );
      
      append_mesh( tris, verts, velocities, masses, new_tris, new_verts, new_velocities, new_masses );
      
      return;
   }
   
   loc = line.find( "create_solid_cylinder", 0 );
   if ( loc != std::string::npos )
   {
      loc += strlen( "create_solid_cylinder" ) + 1;
      
      Vec3d cylinder_end_a, cylinder_end_b;
      
      parse_vec3d( line, loc, cylinder_end_a );     
      ++loc;
      parse_vec3d( line, loc, cylinder_end_b );
      ++loc;
      
      std::string sub = line.substr( loc );
      
      double cylinder_radius = atof( sub.c_str() );
            
      std::cout << cylinder_end_a << std::endl;
      std::cout << cylinder_end_b << std::endl;
      std::cout << cylinder_radius << std::endl;
      
      Array3d cylinder_phi;
      create_capsule_signed_distance( cylinder_end_a,
                                       cylinder_end_b,
                                       cylinder_radius,
                                       domain_dx, 
                                       domain_low, 
                                       domain_high, 
                                       cylinder_phi );
   
      std::vector<Vec3ui> cylinder_tris;
      std::vector<Vec3d> cylinder_verts;
      
      contour_phi( domain_low, domain_dx, cylinder_phi, cylinder_tris, cylinder_verts );
      
      std::vector<Vec3d> cylinder_velocities( cylinder_verts.size(), Vec3d(0,0,0) );
      std::vector<double> cylinder_masses( cylinder_verts.size(), 200.0 );
      
      append_mesh( tris, verts, velocities, masses, cylinder_tris, cylinder_verts, cylinder_velocities, cylinder_masses );  
   }
   
   loc = line.find( "create_solid_cube", 0 );
   if ( loc != std::string::npos )
   {
      loc += strlen( "create_solid_cube" ) + 1;
      
      Vec3d cube_low, cube_high;
      
      parse_vec3d( line, loc, cube_low );     
      ++loc;
      parse_vec3d( line, loc, cube_high );
      ++loc;
      
      Array3d cube_phi;
      
      create_cube_signed_distance( cube_low, cube_high, domain_dx, domain_low, domain_high, cube_phi );
      
      std::vector<Vec3ui> cube_tris;
      std::vector<Vec3d> cube_verts;
      
      contour_phi( domain_low, domain_dx, cube_phi, cube_tris, cube_verts );

      std::vector<Vec3d> cube_velocities( cube_verts.size(), Vec3d(0,0,0) );
      std::vector<double> cube_masses( cube_verts.size(), 200.0 );
      
      append_mesh( tris, verts, velocities, masses, cube_tris, cube_verts, cube_velocities, cube_masses );
      
      return;
   }
   

   loc = line.find( "create_cube", 0 );
   if ( loc != std::string::npos )
   {
      loc += strlen( "create_cube" ) + 1;
      
      Vec3d cube_low, cube_high;
         
      parse_vec3d( line, loc, cube_low );     
      //++loc;
      parse_vec3d( line, loc, cube_high );
      //++loc;
      
      std::cout << "cube_low: " << cube_low << std::endl;
      std::cout << "cube_high: " << cube_low << std::endl;
      
      Array3d cube_phi;
      
      create_cube_signed_distance( cube_low, cube_high, domain_dx, domain_low, domain_high, cube_phi );
      
      std::vector<Vec3ui> cube_tris;
      std::vector<Vec3d> cube_verts;
      
      contour_phi( domain_low, domain_dx, cube_phi, cube_tris, cube_verts );
      
      std::vector<Vec3d> cube_velocities( cube_verts.size(), Vec3d(0,0,0) );
      std::vector<double> cube_masses( cube_verts.size(), 1.0 );
      
      append_mesh( tris, verts, velocities, masses, cube_tris, cube_verts, cube_velocities, cube_masses );

      return;
   }
   
   loc = line.find( "create_sheet", 0 );
   if ( loc != std::string::npos )
   {
      loc += strlen( "create_sheet" ) + 1;
            
      Vec3d low_corner;
      parse_vec3d( line, loc, low_corner );     
      
      Vec3d plane_normal;
      parse_vec3d( line, loc, plane_normal );     

      std::string::size_type space_loc = line.find( " ", loc );
      std::string sub = line.substr( loc, space_loc-loc );      
      double width = atof( sub.c_str() );

      loc = space_loc + 1;
      
      space_loc = line.find( " ", loc );
      sub = line.substr( loc );
      int nx = atoi( sub.c_str() );

      std::vector<Vec3d> sheet_verts;
      std::vector<Vec3ui> sheet_tris;
      
      create_sheet( sheet_verts, sheet_tris, low_corner, plane_normal, width, nx );
      
      std::vector<Vec3d> sheet_velocities( sheet_verts.size(), Vec3d(0,0,0) );
      std::vector<double> sheet_masses( sheet_verts.size(), 1.0 );
            
      append_mesh( tris, verts, velocities, masses, sheet_tris, sheet_verts, sheet_velocities, sheet_masses );
      
      return;
   }

   
   loc = line.find( "create_floor", 0 );
   if ( loc != std::string::npos )
   {
      loc += strlen( "create_floor" ) + 1;
      
      Vec3d low_corner;
      parse_vec3d( line, loc, low_corner );     

      Vec3d plane_normal;
      parse_vec3d( line, loc, plane_normal );     

      std::string::size_type space_loc = line.find( " ", loc );
      std::string sub = line.substr( loc, space_loc-loc );      
      double width = atof( sub.c_str() );

      loc = space_loc + 1;
      
      space_loc = line.find( " ", loc );
      sub = line.substr( loc );
      int nx = atoi( sub.c_str() );
      
      std::vector<Vec3d> floor_verts;
      std::vector<Vec3ui> floor_tris;
      
      std::cout << "floor: low corner: " << low_corner << ", plane_normal: " << plane_normal << ", nx: " << nx << std::endl;
      
      create_sheet( floor_verts, floor_tris, low_corner, plane_normal, width, nx );
      
      std::vector<Vec3d> floor_velocities( floor_verts.size(), Vec3d(0,0,0) );
      std::vector<double> floor_masses( floor_verts.size(), 200.0 );
      
      append_mesh( tris, verts, velocities, masses, floor_tris, floor_verts, floor_velocities, floor_masses );
      
      return;
   }
   
   
   
}

// ---------------------------------------------------------
///
/// Run over all lines in the file, parsing each command, looking for MeshDriver, Simulation, geometry and 
/// SurfTrackInitializationParameters settings.
///
// ---------------------------------------------------------

void parse_script( std::istream& file, 
                  MeshDriver*& driver, 
                  Simulation*& sim, 
                  std::vector<Vec3ui>& tris, 
                  std::vector<Vec3d>& verts, 
                  std::vector<Vec3d>& velocities, 
                  std::vector<double>& masses,
                  SurfTrackInitializationParameters& init )
{
   std::string s;
   while ( std::getline( file, s ) )
   {
      if ( s.substr( 0, 2 ).compare( "//" ) == 0 )
      {
         continue;
      }
                 
      parse_command( s, driver, sim, tris, verts, velocities, masses, init );
   }
}


// ---------------------------------------------------------
///
/// Run over all lines in the file, parsing each command, looking for GUI settings
///
// ---------------------------------------------------------

void parse_gui_script( std::istream& file,
                       float* cam_target,
                       float& cam_distance,
                       float& cam_heading,
                       float& cam_pitch )
{
   std::string line;
   while ( std::getline( file, line ) )
   {
      if ( line.substr( 0, 2 ).compare( "//" ) == 0 )
      {
         continue;
      }
      
      std::string::size_type loc = line.find( "cam_target", 0 );
      if ( loc != std::string::npos )
      {
         loc += strlen( "cam_target" ) + 1;
         
         std::string::size_type space_loc = line.find( " ", loc );
         std::string sub = line.substr( loc, space_loc-loc );
         
         cam_target[0] = (float) atof( sub.c_str() );
         
         loc = space_loc + 1;
         space_loc = line.find( " ", loc );
         sub = line.substr( loc, space_loc-loc );
         
         cam_target[1] = (float) atof( sub.c_str() );
         
         loc = space_loc + 1;
         space_loc = line.find( " ", loc );
         sub = line.substr( loc, space_loc-loc );
         
         cam_target[2] = (float) atof( sub.c_str() );
         
         continue;
      }

      loc = line.find( "cam_distance", 0 );
      if ( loc != std::string::npos )
      {
         loc += strlen( "cam_distance" ) + 1;
         std::string sub = line.substr( loc );
         cam_distance = (float) atof( sub.c_str() );
         continue;
      }

      loc = line.find( "cam_heading", 0 );
      if ( loc != std::string::npos )
      {
         loc += strlen( "cam_heading" ) + 1;
         std::string sub = line.substr( loc );
         cam_heading = (float) atof( sub.c_str() );
         continue;
      }

      loc = line.find( "cam_pitch", 0 );
      if ( loc != std::string::npos )
      {
         loc += strlen( "cam_pitch" ) + 1;
         std::string sub = line.substr( loc );
         cam_pitch = (float) atof( sub.c_str() );
         continue;
      }
      
   }
}
