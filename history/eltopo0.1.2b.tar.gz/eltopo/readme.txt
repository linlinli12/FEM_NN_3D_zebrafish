
EL TOPO: ROBUST TOPOLOGICAL OPERATIONS FOR DYNAMIC EXPLICIT SURFACES
====================================================================================

Building and running:
=====================
Makefile should handle building on Linux and OS/X with g++.  It reads a file called Makefile.local_defs, which contains platform-specific definitions.  You must create this file!  I have included an example Makefile.example_defs which has settings that work for me on my version of Linux and OS/X.

If you want to use the command-line interface, be sure to define NO_GUI in your build.  If you want to use the GUI, be sure to link against OpenGL and GLUT.

Once you have a file called Makefile.local_defs, you can build eltopo by running "make depend", followed by "make release" or "make debug".

Launching eltopo requires two command line parameters:
1) A path to a text "script" file specifying the simulation type and initial geometry (examples from our SISC submission are found in the sisc-scripts/ folder)
2) A path specifying where output files will be written

Example:
[]$ make depend
[]$ make release
[]$ ./eltopo_release sisc-scripts/curlnoise-parameters.txt /var/tmp/

If you are running the GUI, this should pop open a GLUT window for you (see main.cpp to learn what the keyboard does).  If you are running with no GUI, it will immediately start running the simulation, outputting one binary mesh file per frame in /var/tmp/.

Of course, you can always create a project in your favorite IDE, add the source files, and skip the Makefile altogether.


A tour of the code base:
=====================

The main classes you probably want to look at are:

NonDestructiveTriMesh
DynamicSurface
SurfTrack

NonDestructiveTriMesh
---------------------
This is a basic triangle mesh class.  The fundamental data is simply a list of triangles.  It is "nondestructive" in that when you remove a triangle, it marks the triangle as deleted, but doesn't change the size of the list.  The list of triangles can then be defragged as necessary.

There is a set of auxiliary data structures containing various incidence relations.  For example, vtxtri contains, for each vertex, the set of triangles incident on that vertex.  These structures are useful for getting around the mesh, but must be updated when the set of triangles changes.

We generally defrag the list of triangles once per frame if the connectivity changes, then rebuild the auxiliary data structures.

Pretty much any underlying mesh representation should work with our system, as long as it can handle non-manifold and open meshes.

DynamicSurface
---------------------
Main data members of this class are the mesh (NonDestructiveTriMesh) and a set of vertex locations.  Additional data members include per-vertex data such as velocities and masses.

Most important member functions are collision detection and resolution functions.  This class contains enough functionality to advect a surface from one time step to the next in an intersection-free state.

This class would be sufficient for representing cloth if no mesh refinement was required.

SurfTrack
---------------------
A child class of DynamicSurface.  This class contains functions for mesh adaptivity and topological changes.


Drivers:
=====================

The dynamic surface is assigned a linear velocity per vertex by a "mesh driver".  We have a MeshDriver class which defines the interface for assigning these velocities.  This release includes several example drivers:

FaceOffDriver: Motion in the normal direction using Face Offsetting [Jiao 2007].
NormalDriver: Motion in the normal direction using vertex normals.
MeanCurvatureDriver: Motion by mean curvature.
EnrightDriver: The "Enright test" [Enright et al. 2002].
SISCCurlNoiseDriver: Curl noise [Bridson et al. 2007] with parameters set as in our SISC submission.


Other classes and files:
=====================

BroadPhase, BroadPhaseGrid and AccelerationGrid
---------------------
The acceleration structure for broad phase collision detection.  It currently consists of three regular grids, one grid each for triangles, edges and vertices.  Other broad phase approaches could be tried by subclassing the BroadPhase base class.

SubdivisionScheme
---------------------
An interface for interpolating subdivision schemes.  We currently use ButterflySubdivision for all our examples.

simulation, parser, iomesh, marching_tiles
---------------------
Functions for initializing and loading geometry.  Parser is extremely hacky.


Common:
=====================

Common is a set of files shared by our research group.  It contains all sorts of useful things.  Most notably:

vec: A templated n-dimensional vector class.  I use Vec3d (a vector of 3 doubles) all over the place.
mat: A templated matrix class.
gluvi: An OpenGL GUI.
blas_wrapper and lapack_wrapper: Cross-platform interfaces to BLAS and LAPACK functions.



