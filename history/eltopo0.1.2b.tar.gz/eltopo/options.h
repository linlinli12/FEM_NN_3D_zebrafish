// ---------------------------------------------------------
//
//  options.h
//
//  Constants and macro defines
//
// ---------------------------------------------------------

#ifndef OPTIONS_H
#define OPTIONS_H

// ---------------------------------------------------------
// Preproccessor defines
// ---------------------------------------------------------

// Fast as possible, no sanity checking
//
#define SURF_PROFILE

const double UNINITIALIZED_DOUBLE = 0x0F;

#endif

