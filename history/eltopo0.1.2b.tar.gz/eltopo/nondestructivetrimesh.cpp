
// ---------------------------------------------------------
//
//  nondestructivetrimesh.cpp
//  
//  Implementation of NonDestructiveTriMesh: the graph of a 
//  triangle surface mesh.  See header for more details.
//
// ---------------------------------------------------------

// ---------------------------------------------------------
// Includes
// ---------------------------------------------------------

#include <nondestructivetrimesh.h>

#include <cstdarg>
#include <cstdlib>
#include <cmath>
#include <fstream>

#include <wallclocktime.h>


// ---------------------------------------------------------
// Local constants, typedefs, macros
// ---------------------------------------------------------

/// Avoid modulo operator in (i+1)%3
const static unsigned int i_plus_one_mod_three[3] = {1,2,0};

// ---------------------------------------------------------
// Extern globals
// ---------------------------------------------------------

// ---------------------------------------------------------
// Static function definitions
// ---------------------------------------------------------

// --------------------------------------------------------
///
/// Determine whether two edges share the same vertices
///
// --------------------------------------------------------

static bool compare_edges(Vec2ui &e0, Vec2ui &e1)
{
   return (e0[0] == e1[0] && e0[1] == e1[1]) || (e0[0] == e1[1] && e0[1] == e1[0]);
}


// ---------------------------------------------------------
// Member function definitions
// ---------------------------------------------------------

// --------------------------------------------------------
///
/// Clear all mesh information
///
// --------------------------------------------------------

void NonDestructiveTriMesh::clear()
{
   tris.clear();
   clear_connectivity();
}


// --------------------------------------------------------
///
/// Mark a triangle as deleted without actually changing the data structures
///
// --------------------------------------------------------

void NonDestructiveTriMesh::nondestructive_remove_triangle(unsigned int tri)
{
   // Update the vertex->triangle map, vtxtri
   
   Vec3ui& t = tris[tri];
   for(unsigned int i = 0; i < 3; i++)
   {
      // Get the set of triangles incident on vertex t[i]
      std::vector<unsigned int>& vt = vtxtri[t[i]];
      
      for(unsigned int j = 0; j < vt.size(); j++)
      {
         // If a triangle incident on vertex t[i] is tri, delete it
         if(vt[j] == tri)
         {  
            vt.erase( vt.begin() + j );
            --j;
         }
      }
   }

   // Clear t, marking it as deleted
   t = Vec3ui(0,0,0);
   
   // Update the triangle->edge map, triedge
   
   Vec3ui& te = triedge[tri];
   
   for(unsigned int i = 0; i < 3; i++)
   {
      std::vector<unsigned int>& et = edgetri[te[i]];
      
      for( int j = 0; j < (int) et.size(); j++)
      {
         if(et[j] == tri)
         {
            et.erase( et.begin() + j );
            --j;
         }
      }
      
      if ( et.size() == 0 )
      {
         // No triangles are incident on this edge.  Delete it.
         nondestructive_remove_edge( te[i] );
      }            
   }
   
   new (&te) Vec3ui(0,0,0);
   
}


// --------------------------------------------------------
///
/// Add a triangle to the tris structure, update connectivity
///
// --------------------------------------------------------

void NonDestructiveTriMesh::nondestructive_add_triangle( const Vec3ui& tri )
{
   int idx = tris.size();
   tris.push_back(tri);
   triedge.resize(idx+1);
   
   for(unsigned int i = 0; i < 3; i++)
   {
      unsigned int vtx0 = tri[ i ];
      unsigned int vtx1 = tri[ i_plus_one_mod_three[i] ];
            
      // Find the edge composed of these two vertices
      unsigned int e = get_edge(vtx0, vtx1);
      if(e == edges.size())
      {
         // if the edge doesn't exist, add it
         e = add_edge(vtx0, vtx1);
      }
      
      // Update connectivity
      edgetri[e].push_back(idx);       // edge->triangle
      triedge[idx][i] = e;             // triangle->edge
      vtxtri[tri[i]].push_back(idx);   // vertex->triangle
   }
   
}


// --------------------------------------------------------
///
/// Add a vertex, update connectivity.  Return index of new vertex.
///
// --------------------------------------------------------

unsigned int NonDestructiveTriMesh::nondestructive_add_vertex( )
{  
   assert( vtxedge.size() == vtxtri.size() );
   
   vtxedge.resize( vtxedge.size() + 1 );
   vtxtri.resize( vtxtri.size() + 1 );
      
   return vtxtri.size() - 1;
}


// --------------------------------------------------------
///
/// Remove a vertex, update connectivity
///
// --------------------------------------------------------

void NonDestructiveTriMesh::nondestructive_remove_vertex(unsigned int vtx)
{
    
    vtxtri[vtx].clear();    //triangles incident on vertices
    
    // check any edges incident on this vertex are marked as deleted
    for ( unsigned int i = 0; i < vtxedge[vtx].size(); ++i )
    {
       assert( edges[ vtxedge[vtx][i] ][0] == edges[ vtxedge[vtx][i] ][1] );
    }
    
    vtxedge[vtx].clear();   //edges incident on vertices
   
}


// --------------------------------------------------------
///
/// Mark an edge as deleted, update connectivity
///
// --------------------------------------------------------

void NonDestructiveTriMesh::nondestructive_remove_edge( unsigned int edge_index )
{
   // vertex 0
   {
      std::vector<unsigned int>& vertex_to_edge_map = vtxedge[ edges[edge_index][0] ];
      for ( unsigned int i=0; i < vertex_to_edge_map.size(); ++i)
      {
         if ( vertex_to_edge_map[i] == edge_index )
         {
            vertex_to_edge_map.erase( vertex_to_edge_map.begin() + i );
         }
      }
   }

   // vertex 1
   {
      std::vector<unsigned int>& vertex_to_edge_map = vtxedge[ edges[edge_index][1] ];
      for ( unsigned int i=0; i < vertex_to_edge_map.size(); ++i)
      {
         if ( vertex_to_edge_map[i] == edge_index )
         {
            vertex_to_edge_map.erase( vertex_to_edge_map.begin() + i );
         }
      }
   }

   edges[edge_index][0] = 0;
   edges[edge_index][1] = 0;  
}

// --------------------------------------------------------
///
/// Find edge specified by two vertices.  Return edges.size if the edge is not found.
///
// --------------------------------------------------------

unsigned int NonDestructiveTriMesh::get_edge(unsigned int vtx0, unsigned int vtx1) const
{
   assert( vtx0 < vtxedge.size() );
   assert( vtx1 < vtxedge.size() );
   
   const std::vector<unsigned int>& edges0 = vtxedge[vtx0];
   const std::vector<unsigned int>& edges1 = vtxedge[vtx1];
   
   for(unsigned int e0 = 0; e0 < edges0.size(); e0++)
   {
      unsigned int edge0 = edges0[e0];
      
      for(unsigned int e1 = 0; e1 < edges1.size(); e1++)
      {
         if( edge0 == edges1[e1] && edges[edge0][0] != edges[edge0][1] )
         {
            assert( ( edges[edge0][0] == vtx0 && edges[edge0][1] == vtx1 ) ||
                         ( edges[edge0][1] == vtx0 && edges[edge0][0] == vtx1 ) );
            
            return edge0;
         }
      }
   }
   
   return edges.size();
}

// --------------------------------------------------------
///
/// Add an edge to the list.  Return the index of the new edge.
///
// --------------------------------------------------------

unsigned int NonDestructiveTriMesh::add_edge(unsigned int vtx0, unsigned int vtx1)
{
   int edge_index = edges.size();
   edges.push_back(Vec2ui(vtx0, vtx1));
   
   edgetri.resize(edge_index + 1);
   
   vtxedge[vtx0].push_back(edge_index);
   vtxedge[vtx1].push_back(edge_index);
   
   return edge_index;
}


// --------------------------------------------------------
///
/// Remove primitives which have been deleted by nondestructive_remove_whatever
///
// --------------------------------------------------------

void NonDestructiveTriMesh::nondestructive_clear_unused()
{
   clear_connectivity();
   
   // This seems to be faster, on average, than clearing and rebuilding the list of triangles.
   for( int i = 0; i < (int) tris.size(); i++ )
   {
      if( tris[i][0] == tris[i][1] )
      {
         tris.erase( tris.begin() + i );
         --i;
      }
   }
      
}

// --------------------------------------------------------
///
/// Remove auxiliary connectivity information
///
// --------------------------------------------------------

void NonDestructiveTriMesh::clear_connectivity()
{
   edges.clear();
   vtxedge.clear();
   vtxtri.clear();
   edgetri.clear();
   triedge.clear();
}


// --------------------------------------------------------
///
/// Clear and rebuild connectivity information
///
// --------------------------------------------------------

void NonDestructiveTriMesh::update_connectivity( unsigned int nv )
{
      
   clear_connectivity();
   
   vtxtri.resize(nv);
   vtxedge.resize(nv);
   triedge.resize(tris.size());
   
   for(unsigned int i = 0; i < tris.size(); i++)
   {
      Vec3ui& t = tris[i];
      
      if(t[0] != t[1])
      {
         
         for(unsigned int j = 0; j < 3; j++)
            vtxtri[t[j]].push_back(i);
         
         Vec3ui& te = triedge[i];
         
         for(int j = 0; j < 3; j++)
         {
            unsigned int vtx0 = t[j];
            unsigned int vtx1 = t[(j+1)%3];
            
            unsigned int e = get_edge(vtx0, vtx1);
            
            if(e == edges.size())
            {
               e = add_edge(vtx0, vtx1);
            }
            
            te[j] = e;
            edgetri[e].push_back(i);
         }
      }
   }
   
   for ( unsigned int e = 0; e < edges.size(); ++e )
   {
      const Vec2ui& ce = edges[e];
      const std::vector<unsigned int>& et = edgetri[e];
      for ( unsigned int t = 0; t < et.size(); ++t )
      {
         unsigned int third = get_third_vertex( ce[0], ce[1], tris[et[t]] );
         (void) third;
      }
   }
   
}


// --------------------------------------------------------
///
/// Sanity check connectivity information
///
// --------------------------------------------------------

bool NonDestructiveTriMesh::check_connectivity()
{
   std::cout << "checking connectivity" << std::endl;
   
   if(edges.size() == 0 || vtxedge.size() == 0 || edgetri.size() == 0 || triedge.size() == 0)
   {
      std::cout << "connectivity not set" << std::endl;
      return false;
   };
   
   std::vector<Vec2ui> old_edges = edges;
   std::vector<std::vector<unsigned int> > old_vtxedge = vtxedge;
   std::vector<std::vector<unsigned int> > old_vtxtri = vtxtri;
   std::vector<std::vector<unsigned int> > old_edgetri = edgetri;
   std::vector<Vec3ui> old_triedge = triedge;
   
   unsigned int nv = vtxtri.size();
   
   update_connectivity(nv);
   
   //check for degenerate triangles
   for(unsigned int i = 0; i < tris.size(); i++)
   {
      Vec3ui t = tris[i];
      
      if((t[0] != t[1] || t[1] != t[2] || t[2] != t[0])
         && (t[0] == t[1] || t[1] == t[2] || t[2] == t[0]))
      {
         std::cout << "degenerate triangle found " << t << std::endl;
         assert(0);
         return false;
      };
   };
   
   //check to so that the minimal set of edges is a subset of the current edges
   for(unsigned int i = 0; i < edges.size(); i++)
   {
      Vec2ui e = edges[i];
      bool found = false;
      for(unsigned int j = 0; j < old_edges.size(); j++)
      {
         Vec2ui oe = old_edges[j];
         if(compare_edges(e, oe))
         {
            if(found)
            {
               std::cout << "duplicate edge" << std::endl;
               assert(0);
               return false;
            };
            found = true;
         };
      };
      if(!found)
      {
         std::cout << "missing edge " << e << std::endl;
         assert(0);
         return false;
      };
   };
   
   //check that each vertex has the same incident edges
   for(unsigned int i = 0; i < nv; i++)
   {
      std::vector<unsigned int> ove = old_vtxedge[i];
      std::vector<unsigned int> ve = vtxedge[i];
      
      //std::cout << "vtx edge " << ove.size() << " " << ve.size() << std::endl;
      
      //if(ove.size() != ve.size())
      //  return false;
      
      for(unsigned int j = 0; j < ve.size(); j++)
      {
         Vec2ui e = edges[ve[j]];
         bool found = false;
         for(unsigned int k = 0; k < ove.size(); k++)
         {
            Vec2ui oe = old_edges[ove[k]];
            
            if(compare_edges(e, oe))
            {
               if(found)
               {
                  std::cout << "duplicate vertex incident edge" << std::endl;
                  assert(0);
                  return false;
               };
               found = true;
            };
         };
         if(!found)
         {
            std::cout << "missing vertex incident edge" << std::endl;
            assert(0);
            return false;
         };
      };
   };
   
   //check that no removed triangles are still incident on edges
   for(unsigned int i = 0; i < old_edges.size(); i++)
   {
      std::vector<unsigned int> oet = old_edgetri[i];
      for(unsigned int j = 0; j < oet.size(); j++)
      {
         if(tris[oet[j]][0] == tris[oet[j]][1])
         {
            std::cout << "edge incident removed triangle" << std::endl;
            assert(0);
            return false;
         };
      };
   };
   
   //check that each edge has the same set of incident triangles
   for(unsigned int i = 0; i < old_edges.size(); i++)
   {
      Vec2ui oe = old_edges[i];
      
      if ( oe[0] == oe[1] ) { continue; }
      
      Vec2ui e;
      
      std::vector<unsigned int> oet = old_edgetri[i];
      std::vector<unsigned int> et;
      
      for(unsigned int j = 0; j < edges.size(); j++)
      {
         e = edges[j];
         
         if(compare_edges(e, oe))
         {
            et = edgetri[j];
            break;
         };
      };
      
      if(oet.size() != et.size())
      {
         std::cout << "incorrect number of edge incident triangles" << std::endl;
         assert(0);
         return false;
      };
      
      for(unsigned int j = 0; j < et.size(); j++)
      {
         unsigned int t = et[j];
         bool found = false;
         for(unsigned int k = 0; k < oet.size(); k++)
         {
            if(oet[k] == t)
            {
               if(found)
               {
                  std::cout << "duplicate edge incident triangle" << std::endl;
                  std::cout << "edge has " << oet.size() << " incident triangles" << std::endl;
                  
                  for(int l = 0; l < (int)et.size(); l++)
                     std::cout << " " << et[l];
                  std::cout << std::endl;
                  
                  for(int l = 0; l < (int)oet.size(); l++)
                     std::cout << " " << oet[k];
                  std::cout << std::endl;
                  
                  assert(0);
                  return false;
               };
               found = true;
            };
         };
         if(!found)
         {
            std::cout << "missing edge incident triangle" << std::endl;
            assert(0);
            return false;
         };
      };
   };
   
   //check whether each triangle has the same incident edges
   for(unsigned int i = 0; i < tris.size(); i++)
   {
      Vec3ui t = tris[i];
      if(t[0] != t[1])
      {
         Vec3ui ote = old_triedge[i];
         Vec3ui te = triedge[i];
         
         for(unsigned int j = 0; j < 3; j++)
         {
            Vec2ui e = edges[te[j]];
            bool found = false;
            for(int k = 0; k < 3; k++)
            {
               //std::cout << "tri edges " << k << " " << ote[k] << std::endl;
               
               Vec2ui oe = old_edges[ote[k]];
               
               if(compare_edges(e, oe))
               {
                  if(found)
                  {
                     std::cout << "duplicate triangle edge" << std::endl;
                     assert(0);
                     return false;
                  };
                  found = true;
               };
            };
            if(!found)
            {
               std::cout << "missing triangle edge" << std::endl;
               assert(0);
               return false;
            };
         };
      };
   };
   
   //check whether triangles incident on vertices is correct
   for(unsigned int i = 0; i < old_vtxtri.size(); i++)
   {
      std::vector<unsigned int> ovt = old_vtxtri[i];
      std::vector<unsigned int> vt = vtxtri[i];
      
      if(ovt.size() != vt.size())
      {
         std::cout << "vertex incident triangles unequal" << std::endl;
         
         for ( unsigned int ii=0; ii < ovt.size(); ++ii )
         {
            std::cout << "ovt: " << ovt[ii] << std::endl;
         }
         for ( unsigned int ii=0; ii < vt.size(); ++ii )
         {
            std::cout << "vt: " << vt[ii] << std::endl;
         }
         
         assert(0);
         return false;
      };
      
      for(unsigned int k = 0; k < vt.size(); k++)
      {
         bool found = false;
         for(unsigned int j = 0; j < ovt.size(); j++)
         {
            if(vt[k] == ovt[j])
            {
               found = true;
               break;
            };
         };
         if(!found)
         { 
            std::cout << "missing vertex incident triangle" << std::endl;
            assert(0);
            return false;
         };
      };
   };
   
   edges = old_edges;
   vtxedge = old_vtxedge;
   edgetri = old_edgetri;
   triedge = old_triedge;
   
   return true;
}


// --------------------------------------------------------
///
/// Dump some information about this NonDestructiveTriMesh to stdout
///
// --------------------------------------------------------

void NonDestructiveTriMesh::print_state()
{
   int usedtris = 0;
   for(unsigned int i = 0; i < tris.size(); i++)
   {
      if(tris[i][0] != tris[i][1] && tris[i][1] != tris[i][2] && tris[i][2] != tris[i][0])
      {
         usedtris++;
      }
   }
   
   int usededges = 0;
   for(int i = 0; i < (int)edges.size(); i++)
   {
      if(edges[i][0] != edges[i][1])
      {
         usededges++;
      }
   }
   
   unsigned int nv = vtxtri.size();
   
   int usedvertices = 0;
   bool *uv = new bool[nv];
   for( unsigned int i = 0; i < nv; i++)
   {
      uv[i] = false;
   }
   
   for( unsigned int i = 0; i < tris.size(); i++)
   {
      if(tris[i][0] != tris[i][1] && tris[i][1] != tris[i][2] && tris[i][2] != tris[i][0])
      {
         if(tris[i][0] >= nv || tris[i][1] >= nv && tris[i][2] >= nv)
         {
            usedvertices = -1;
            break;
         };
         
         uv[tris[i][0]] = true;
         uv[tris[i][1]] = true;
         uv[tris[i][2]] = true;
      }
   }
   
   if(usedvertices != -1)
   {
      for( unsigned int i = 0; i < nv; i++)
      {
         if(uv[i])
         {
            usedvertices++;
         }
      }
   }
   
   std::cout << "connectivity: " << (check_connectivity()?"correct":"broken") << std::endl;
   std::cout << "triangles: " << usedtris << "/" << tris.size() << std::endl;
   std::cout << "edges: " << usededges << "/" << edges.size() << std::endl;
   std::cout << "vertices: " << usedvertices << "/" << nv << std::endl;
   
   delete[] uv;
}
